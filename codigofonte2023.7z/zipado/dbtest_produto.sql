-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: dbtest
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome_produto` varchar(30) DEFAULT NULL,
  `descricao_produto` varchar(100) DEFAULT NULL,
  `valor_produto` float DEFAULT NULL,
  `Marca` varchar(30) NOT NULL,
  `id_categoria_3` int DEFAULT NULL,
  `id_subcategoria_2` int DEFAULT NULL,
  `id_fornecedor_2` int DEFAULT NULL,
  `imagem_produto` text,
  PRIMARY KEY (`id_produto`),
  KEY `id_categoria_3` (`id_categoria_3`),
  KEY `id_subcategoria_2` (`id_subcategoria_2`),
  KEY `id_fornecedor_2` (`id_fornecedor_2`),
  CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`id_categoria_3`) REFERENCES `categorias` (`id_categoria`),
  CONSTRAINT `produto_ibfk_2` FOREIGN KEY (`id_subcategoria_2`) REFERENCES `subcategorias` (`id_subcategoria`),
  CONSTRAINT `produto_ibfk_3` FOREIGN KEY (`id_fornecedor_2`) REFERENCES `fornecedor` (`id_fornecedor`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'Whisky Jack Daniels','Whisky com sabor forte e excêntrico! Ideal para combinação com gelos com sabor e energético.',170,'Jack Daniels',1,1,2,'https://cdn.sistemawbuy.com.br/arquivos/a48e76d3b4ff8b6e919e194fd7dfcfed/produtos/641b34cb1a44a/jackdaniels-641b34cb557cd.png'),(2,'Whisky Ballantines','Whisky suave e adocicado. Ideal para drinks!',120,'Ballantines',1,1,3,'https://www.ballantines.com/wp-content/uploads/2020/12/Finest-Dark-70cl-Bottle-Front-Transparent-Background-2.png'),(3,'Whisky Passport','Whisky com sabor moderado. ',80,'Passport',1,1,3,'https://www.imigrantesbebidas.com.br/bebida/images/products/full/6341-whisky-passport-scotch-1l.jpg'),(4,'Cerveja Skol','A cerveja que desce redondo! ',2.69,'Skol',1,9,1,'https://giassi.vtexassets.com/arquivos/ids/579431/Cerveja-Pilsen-Skol-Lata-350ml.png?v=638137339571400000'),(5,'Cerveja Heineken','Cerveja oficial da Champions  League!',3.19,'Heineken',1,9,4,'https://d2r9epyceweg5n.cloudfront.net/stores/001/043/122/products/cerveja-heineken-lata-350-ml1-157b2e5b56d0a3b51c15676907824683-640-0.jpg'),(6,'Cerveja SPATEN','Cerveja alemã com características regionais!',4.29,'Spaten',1,9,1,'https://m.media-amazon.com/images/I/510WKbIyWiL.jpg'),(7,'Cerveja Império','A cerveja querida pelos brasileiros!',3.33,'Império',1,9,5,'https://nossadistribuidorabebidas.com.br/wp-content/uploads/2021/11/Cerveja-Imperio-269ml.png'),(8,'Vodka Cîroc','Vodka francesa conceituada na indústria alcoólica!',169,'Cîroc',1,3,2,'https://m.media-amazon.com/images/I/41OVvtvfWeL.jpg'),(9,'Vodka Askov ','Vodka utilizada em criação de drinks!',15,'Askov',1,3,2,'https://images.tcdn.com.br/img/img_prod/1161470/vodka_askov_natural_900_ml_2009_1_fedde3ceaac247bfaba92e117951ee7f.png'),(10,'Vodka Askov Frutas Vermelhas','Vodka com sabor inovador de frutas vermelha!',18,'Askov',1,3,2,'https://m.media-amazon.com/images/I/71oHHex5rSL.jpg'),(11,'Whisky Cockland','Whisky nacional produzido na serra Gaúcha!',50,'Cockland',1,1,3,'https://www.imigrantesbebidas.com.br/bebida/images/products/full/6348-whisky-cockland-985-ml.jpg'),(12,'Whisky Black & White','Whisky escocês blended.\r\n',64,'Black & White',1,1,3,'https://m.media-amazon.com/images/I/71yduG8G19L.jpg'),(13,'Tequila Teqpar','Tequila suave!',35,'Teqpar',1,7,2,'https://upside.vteximg.com.br/arquivos/ids/159703-1000-1000/17021.jpg?v=637491113854730000'),(15,'Coquetel Master Gold','Coquetel Reluzente!',19,'Master Gold',1,11,2,'https://ibassets.com.br/ib.item.image.big/b-a5b5fb2d41a44f67a73ce7c39aaf8ba6.jpeg'),(16,'Vinho San Tomé','Vinho tradicional do Brasil para os Brasileiros!',20.6,'San Tomé',1,11,2,'https://coopsp.vtexassets.com/arquivos/ids/227818/7896403900015.jpg?v=638074200357900000'),(17,'Chopp Draft','Chopp saborizado de vinho!',11,'Draft',1,12,2,'https://d2r9epyceweg5n.cloudfront.net/stores/001/043/122/products/draft1-684ec018710e9c685b15700309614823-640-0.png'),(18,'Coquetel de Vinho Cantinho do ','O coquetel mais famoso do Brasil!',11,'Cantinho do Vale',1,12,3,'https://www.hsbebidas.com.br/wp-content/uploads/2018/02/Coquetel-de-Vinho-Cantinho-do-Vale-Tinto-Suave-Pet-880-ml-1-600x600.jpg'),(19,'Cachaça Jurupinga','Não te juro amor, mas te Jurupinga!',30,'Jurupinga',1,2,1,'https://acdn.mitiendanube.com/stores/001/133/427/products/jurupinga1-c62e62814329cd0da916454903593095-640-0.jpeg'),(20,'Engradado de Cerveja Spoten','Engradado com 12 unidades.',51.4,'Spoten',1,10,3,'https://www.adegadobonfa.com.br/produtos/fotos/grande/596-spaten-pack-lata-8-x-269ml.png'),(21,'Engradado de Cerveja Amstel','Engradado com 12 unidades.',44.9,'Amstel',1,10,4,'https://www.comercialzl.com.br/image/cache/watermark/data/eftr/Img_ftr_rp_6102-1160x1160.JPG'),(22,'Engradado de Cerveja Petra','Engradado com 12 unidades.',41.9,'Petra',1,10,2,'https://ibassets.com.br/ib.item.image.big/b-d7cee2f0e9914be3bfb782ba8a722387.jpeg'),(23,'Whisky Ballantines','Whisky nobre e adocicado',162,'Ballantines',1,1,2,'https://www.casadabebida.com.br/img/products/whisky-jack-daniels_1_600.jpg'),(24,'Whisky Jack Daniels','O whisky querido pelos brasileiros',190,'Jack Daniels',1,1,3,'https://www.casadabebida.com.br/img/products/whisky-jack-daniels_1_600.jpg'),(25,'Cabaré Canela','A cachaça da cidade de Mirassol!',35,'Cabaré Canela',1,2,2,'https://www.bebidaonline.com.br/media/catalog/product/cache/1/thumbnail/800x/99cfa2db909aa8be0aba7059fa3f7550/c/a/cachaca_cabare_fire_coquetel_canela_1l.jpg'),(26,'Fuego Loco','Tequila ',15.5,'Fuego Loco',1,7,2,'https://a-static.mlcdn.com.br/450x450/tequila-fuego-loco-900ml-tekleiro/moradadodrink/837c7b2ede0111eda8c74201ac185033/beabd6dfb41685591e2860a8aecbc17d.jpeg'),(27,'Kariri','Aguardente artesanal',20,'Kariri',1,2,3,'https://m.media-amazon.com/images/I/519KG33XMML.jpg'),(28,'Velho Barreiro','A cachaça tradicional dos brasileiros',11.5,'Velho Barreiro',1,2,3,'https://m.media-amazon.com/images/I/51c92vDw3IL.jpg'),(29,'Seleta ','Cachaça indistinguível',40,'Seleta',1,2,3,'https://cachacarianacional.vteximg.com.br/arquivos/ids/167654-1000-1000/cachaca-seleta-ouro-1000ml-so-01215_1.jpg?v=637915932830370000'),(30,'Cabaré Ouro','Cachaça dos sertanejos Eduardo Costa e Leonardo',30,'Cabaré',1,2,2,'https://www.imigrantesbebidas.com.br/img/bebida/images/products/full/11198-cachaca-cabare-ouro-700ml.jpg?s=241d55b5fdca34cf34feec85de2da9d6'),(31,'Cabaré Prata','Pega fogo cabaré',30,'Cabaré',1,2,2,'https://images.tcdn.com.br/img/img_prod/902185/cachaca_cabare_prata_323_1_ebd468e8fb92e98d2a25ffa21916e8e3.jpg'),(32,'Rock ','Vou parar de tomar gin? Acho que não',36,'Rock',1,6,2,'https://www.imigrantesbebidas.com.br/bebida/images/products/full/9041-gin-rocks-seco-1l.20230227135838.jpg'),(33,'Engradado Antártica 350 ml','Caixa com 12 unidades',40,'Antártica',1,10,3,'https://ibassets.com.br/ib.item.image.big/b-d747682b8c0642efa8dc10c9c50e6161.jpeg'),(34,'Engradado Antártica 269 ml','Caixa com 12 unidades',42.37,'',NULL,NULL,NULL,'https://courier-images-prod.imgix.net/product/00008887_87cca924-cf89-461b-9b9d-fd2b2b8bf7ad.jpg?auto=compress,format&fit=max&w=undefined&h=undefined&dpr=2?auto=compress,format&fit=max&w=undefined&h=undefined&dpr=2'),(35,'Engradado Budwaiser 350 ml','Caixa com 12 unidades',51,'Budwaiser',1,10,3,'https://emporiodacerveja.vtexassets.com/arquivos/ids/164476/Budweiser-269ml-Lata-8-unidades-1.jpg?v=636264962210200000'),(36,'Engradado Corona 350 ml','Caixa com 6 unidades',45,'Corona',1,10,3,'https://assets.b9.com.br/wp-content/uploads/2021/07/cerveja-corona-latas-1280x677.jpg\n'),(37,'Engradado Original 350 ml','Caixa com 12 unidades',51.5,'Original',1,10,3,'https://imgs.extra.com.br/55017376/1g.jpg'),(38,'Pulinho',NULL,120,'safada',NULL,NULL,NULL,NULL),(39,'Pulinhoa',NULL,122,'safadinho',NULL,NULL,NULL,NULL),(40,'Sarah',NULL,NULL,'Skol',NULL,NULL,NULL,NULL),(41,'s',NULL,NULL,'s',NULL,NULL,NULL,NULL),(42,'s',NULL,NULL,'s',NULL,NULL,NULL,NULL),(43,'s',NULL,NULL,'s',NULL,NULL,NULL,NULL),(44,'s',NULL,NULL,'s',NULL,NULL,NULL,NULL),(45,'s',NULL,NULL,'s',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-06  8:34:23
