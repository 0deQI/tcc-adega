const express = require('express');
const app = express();
const mysql = require('mysql2');
const cors = require('cors');
const admin = require('firebase-admin');
const serviceAccount = require('..//client/src/components/services/react-auth-bc20e-firebase-adminsdk-mbxrp-9c17b88345.json'); 
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '12345',
  database: 'dbtest',
  port:3309
});
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});


app.use(cors());
app.use(express.json());

app.get('/buscarProduto', (req, res) => {
  const { nome } = req.query;
  console.log('Parâmetro nome:', nome); 
  const SQL = 'SELECT * FROM produto WHERE nome_produto LIKE ?';

  db.query(SQL, [`%${nome}%`], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao buscar produtos.');
    } else {
      res.status(200).json(result);
    }
  });
});

app.get("/getProdutosEngradado", (req, res) => {
  let SQL = "SELECT * FROM produto WHERE nome_produto LIKE 'Engradado%'";
  db.query(SQL, (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).send("Erro ao buscar produtos.");
    } else {
      res.status(200).json(result);
    }
  });
});

app.get('/getBanners', (req, res) => {
  const SQL = 'SELECT * from banner';
  db.query(SQL, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao buscar banners.');
    } else {
      res.status(200).json(result);
    }
  });
});

app.get('/getProdutos', (req, res) => {
  const SQL = 'SELECT * from produto';
  db.query(SQL, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao buscar produtos.');
    } else {
      res.status(200).json(result);
    }
  });
});

app.post('/register', (req, res) => {
  const { id_cliente, nome_cliente, email_cliente, senha_cliente, endereco_cliente, telefone_cliente } = req.body;

  // verifica se já existe um registro com o mesmo email
  const SQLCheckExistingEmail = 'SELECT * FROM clientes WHERE email_cliente = ?';
  db.query(SQLCheckExistingEmail, [email_cliente], (errEmail, resultEmail) => {
    if (errEmail) {
      console.error(errEmail);
      return res.status(500).json({ message: 'Erro ao verificar registros existentes.' });
    } else {
      if (resultEmail.length > 0) {
        return res.status(400).json({ field: 'email', message: 'Email já cadastrado.' });
      } else {
        // verifica se já existe um registro com o mesmo id_cliente
        const SQLCheckExistingIdClientes = 'SELECT * FROM clientes WHERE id_cliente = ?';
        db.query(SQLCheckExistingIdClientes, [id_cliente], (errIdClientes, resultIdClientes) => {
          if (errIdClientes) {
            console.error(errIdClientes);
            return res.status(500).json({ message: 'Erro ao verificar registros existentes.' });
          } else {
            if (resultIdClientes.length > 0) {
              return res.status(400).json({ field: 'id_cliente', message: 'CPF já cadastrado.' });
            } else {
              // verifica se já existe um registro com o mesmo telefone
              const SQLCheckExistingTelefone = 'SELECT * FROM clientes WHERE telefone_cliente = ?';
              db.query(SQLCheckExistingTelefone, [telefone_cliente], (errTelefone, resultTelefone) => {
                if (errTelefone) {
                  console.error(errTelefone);
                  return res.status(500).json({ message: 'Erro ao verificar registros existentes.' });
                } else {
                  if (resultTelefone.length > 0) {
                    return res.status(400).json({ field: 'telefone', message: 'Telefone já cadastrado.' });
                  } else {
                    // novo registro no banco de dados
                    const SQLInsert = "INSERT INTO clientes (id_cliente, nome_cliente, email_cliente, senha_cliente, endereco_cliente, telefone_cliente) VALUES (?, ?, ?, ?, ?, ?)";
                    db.query(SQLInsert, [id_cliente, nome_cliente, email_cliente, senha_cliente, endereco_cliente, telefone_cliente], (errInsert, resultInsert) => {
                      if (errInsert) {
                        console.error(errInsert);
                        return res.status(500).json({ message: 'Erro ao realizar o cadastro.' });
                      } else {
                        console.log('Cadastro bem-sucedido.');
                        return res.status(200).json({ message: 'Cadastro realizado com sucesso.' });
                      }
                    });
                  }
                }
              });
            }
          }
        });
      }
    }
  });
});
app.post('/login', (req, res) => {
  console.log('Recebendo solicitação de login...');
  const { email_cliente, senha_cliente } = req.body;

  if (!email_cliente || !senha_cliente) {
    console.log('Email ou senha ausentes.');
    res.status(400).json({ message: 'Email e senha são obrigatórios' });
    return;
  }

  const SQL = 'SELECT id_cliente, email_cliente, senha_cliente FROM clientes WHERE email_cliente = ? AND senha_cliente = ?';
  db.query(SQL, [email_cliente, senha_cliente], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: 'Erro ao realizar login' });
    } else {
      if (result.length > 0) {
        console.log('Login bem-sucedido.');
        const user = result[0];
        res.status(200).json({ success: true, message: 'Login bem-sucedido', user });
      } else {
        console.log('Email ou senha incorretos.');
        res.status(401).json({ success: false, message: 'Email ou senha incorretos' });
      }
    }
  });
});

app.post("/registroProduto", (req,res)=>{
  const {nome_produto} = req.body;
  const {valor_produto} = req.body;
  const {Marca} = req.body;
  const {id_produto} = req.body;
  const {descricao_produto} = req.body;
  const {unidade_produto} = req.body;
  const {id_categoria_3} = req.body;
  const {id_subcategoria_2} = req.body;
  const {id_fornecedor_2} = req.body;
  const {imagem_produto} = req.body;
 
 let SQL = "INSERT INTO produto (id_produto, descricao_produto, unidade_produto, id_categoria_3, id_subcategoria_2,  id_fornecedor_2, imagem_produto, nome_produto, valor_produto, Marca) VALUES( ?,?,?,?,?,?,?,?,?,? )";
 // mandar pro banco
 db.query(SQL, [id_produto, descricao_produto, unidade_produto,
   id_categoria_3, id_subcategoria_2, id_fornecedor_2, imagem_produto, nome_produto, valor_produto, Marca], (err, result)=>{
 console.log(err);
 }
 )
 });
 app.get('/api/getUserId', async (req, res) => {
  try {
    const token = req.headers.authorization.replace('Bearer ', '');

    // verificando o token JWT usando o Firebase Admin SDK
    const decodedToken = await admin.auth().verifyIdToken(token);
    const email_cliente = decodedToken.email; // Obtém o email autenticado do usuário Firebase

    // consultando o banco de dados para encontrar o id_cliente associado a esse email
    const SQL = 'SELECT id_cliente FROM clientes WHERE email_cliente = ?';

    db.query(SQL, [email_cliente], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'Erro na consulta SQL.' });
      }

      if (result.length > 0) {
        const id_cliente = result[0].id_cliente;
        console.log('id_cliente encontrado:', id_cliente);
        return res.status(200).json({ id_cliente });
      } else {
        console.log('Nenhum registro correspondente encontrado.');
        return res.status(404).json({ message: 'Usuário não encontrado no banco de dados.' });
      }
    });
  } catch (error) {
    console.error('Erro ao verificar o token JWT:', error);
    return res.status(401).json({ message: 'Token JWT inválido ou expirado.' });
  }
});


 
 app.get("/getCards", (req,res) =>{
   let SQL = "SELECT * from produto";
   db.query(SQL, (err, result)=>{
     if(err) console.log('resultado')
     else res.send(result);
   })
 })



app.listen(3001, () => {
  console.log('Servidor rodando na porta 3001');
});

app.delete('/deleteProduto/:id_produto', (req, res) => {
  const { id_produto } = req.params;

  const SQL = 'DELETE FROM produto WHERE id_produto = ?';

  db.query(SQL, [id_produto], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao excluir o produto.');
    } else {
      console.log('Produto excluído com sucesso.');
      res.status(200).json({ message: 'Produto excluído com sucesso.' });
    }
  });
});

app.put('/updateProduto/:id_produto', (req, res) => {
  const { id_produto } = req.params;
  const updatedData = req.body; 
  const updateFields = [];
  const updateValues = [];

  for (const key in updatedData) {
    updateFields.push(`${key} = ?`);
    updateValues.push(updatedData[key]);
  }

  const SQL = `UPDATE produto SET ${updateFields.join(', ')} WHERE id_produto = ?`;
  updateValues.push(id_produto); 

  db.query(SQL, updateValues, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao atualizar o produto.');
    } else {
      console.log('Produto atualizado com sucesso.');
      res.status(200).json({ message: 'Produto atualizado com sucesso.' });
    }
  });
});

app.post("/adicionarAoCarrinho", (req, res) => {
  console.log('Recebendo solicitação para adicionar ao carrinho...');
  const { id_produto, quantidade, id_cliente } = req.body;
  console.log('Parâmetros recebidos:', id_produto, quantidade, id_cliente);


  const SQLCheckProduct = 'SELECT * FROM produto WHERE id_produto = ?';
  db.query(SQLCheckProduct, [id_produto], (err, productResult) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Erro ao buscar o produto.' });
    }

    if (productResult.length === 0) {
      return res.status(404).json({ message: 'Produto não encontrado.' });
    }

    const product = productResult[0];

   
  const SQLInsertCartItem = 'INSERT INTO itens_carrinho (id_produto, quantidade, id_cliente) VALUES (?, ?, ?)';
  db.query(SQLInsertCartItem, [id_produto, quantidade, id_cliente], (errInsert, insertResult) => {
    if (errInsert) {
      console.error(errInsert);
      return res.status(500).json({ message: 'Erro ao adicionar ao carrinho.' });
    }
    return res.status(200).json({ message: 'Produto adicionado ao carrinho com sucesso.' });
  });
});
});

app.get('/getUserId', (req, res) => {
  const user = req.user; // verificando se o usuário está autenticado

  if (user) {
    const email_cliente = user.email;

    const SQL = 'SELECT id_cliente FROM clientes WHERE email_cliente = ?';

    db.query(SQL, [email_cliente], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'Erro na consulta SQL.' });
      }

      if (result.length > 0) {
        const id_cliente = result[0].id_cliente;
        console.log('id_cliente encontrado:', id_cliente);
        return res.status(200).json({ id_cliente });
      } else {
        console.log('Nenhum registro correspondente encontrado.');
        return res.status(404).json({ message: 'Usuário não encontrado no banco de dados.' });
      }
    });
  } else {
    console.log('Usuário não autenticado.');
    res.status(401).json({ message: 'Usuário não autenticado.' });
  }
});

app.get('/getItensCarrinho', (req, res) => {
  const { id_cliente } = req.query;

  const SQL = `
    SELECT itens_carrinho.*, produto.nome_produto, produto.valor_produto, produto.imagem_produto
    FROM itens_carrinho
    INNER JOIN produto ON itens_carrinho.id_produto = produto.id_produto
    WHERE itens_carrinho.id_cliente = ?`;

  db.query(SQL, [id_cliente], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao buscar itens do carrinho.');
    } else {
      res.status(200).json(result);
    }
  });
});



app.put('/updateQuantity', (req, res) => {
  const { id_itens_carrinho, newQuantity } = req.body;

  const SQL = 'UPDATE itens_carrinho SET quantidade = ? WHERE id_itens_carrinho = ?';
  db.query(SQL, [newQuantity, id_itens_carrinho], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ success: false, message: 'Erro ao atualizar a quantidade.' });
    } else {
      res.status(200).json({ success: true, message: 'Quantidade atualizada com sucesso.' });
    }
  });
});

app.delete('/removeFromCart/:id_itens_carrinho', (req, res) => {
  const { id_itens_carrinho } = req.params;

  const SQL = 'DELETE FROM itens_carrinho WHERE id_itens_carrinho = ?';

  db.query(SQL, [id_itens_carrinho], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Erro ao excluir o item do carrinho.');
    } else {
      console.log('Item do carrinho excluído com sucesso.');
      res.status(200).json({ success: true });
    }
  });
});


app.put('/consolidateCart', (req, res) => {
  const { id_cliente } = req.body;

  const SQL = `
    SELECT id_produto, SUM(quantidade) as quantidade
    FROM itens_carrinho
    WHERE id_cliente = ?
    GROUP BY id_produto
  `;

  db.query(SQL, [id_cliente], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ success: false, message: 'Erro ao consolidar o carrinho.' });
    } else {
      const consolidatedCart = result;

      res.status(200).json({ success: true, consolidatedCart });
    }
  });
});

app.post("/adicionarAoBanner", (req, res) => {
  const { id_banner, link_banner } = req.body;

  const query = "INSERT INTO banner (id_banner, link_banner) VALUES (?, ?)";
  db.query(query, [id_banner, link_banner], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send("Erro ao adicionar ao Banner");
    } else {
      res.status(200).send("Dados adicionados ao Banner com sucesso");
    }
  });
});

app.delete("/excluirBanner/:id", (req, res) => {
  const bannerId = req.params.id;

  const query = "DELETE FROM banner WHERE id_banner = ?";
  
  db.query(query, [bannerId], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send("Erro ao excluir o banner");
    } else {
      res.status(200).send("Banner excluído com sucesso");
    }
  });
});

app.get("/bannerdados", (req, res) => {
  const query = "SELECT * FROM banner";
  db.query(query, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send("Erro ao buscar dados da tabela banner");
    } else {
      res.status(200).json(result);
    }
  });
});


app.get("/getSliderData", (req, res) => {
  const sql = "SELECT * FROM slider";
  db.query(sql, (err, results) => {
    if (err) {
      console.error("Erro na consulta SQL:", err);
      res.status(500).json({ error: "Erro ao buscar dados do slider" });
    } else {
      res.json(results);
    }
  });
});

app.delete('/api/deleteSlider/:id_slider', (req, res) => {
  const { id_slider } = req.params;
  const SQL = 'DELETE FROM slider WHERE id_slider = ?';

  db.query(SQL, [id_slider], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Erro ao excluir dados do slider' });
    } else {
      res.json({ message: 'Dados do slider excluídos com sucesso' });
    }
  });
});


app.post("/addSliderData", (req, res) => {
  const { id_slider, link_slider } = req.body;
    if (!id_slider || !link_slider) {
    return res.status(400).json({ error: "ID Slider and Link Slider are required." });
  }

  const SQL = 'INSERT INTO slider (id_slider, link_slider) VALUES (?, ?)';
  db.query(SQL, [id_slider, link_slider], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Erro ao adicionar dados ao slider" });
    }

    return res.status(200).json({ message: "Dados adicionados ao slider com sucesso" });
  });
});

app.post("/adicionarSlider", (req, res) => {
  const { id_slider, link_slider } = req.body;

  const SQLInsert = "INSERT INTO slider (id_slider, link_slider) VALUES (?, ?)";
  
  db.query(SQLInsert, [id_slider, link_slider], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: 'Erro ao adicionar dados ao slider.' });
    } else {
      console.log('Dados adicionados ao slider com sucesso.');
      res.status(200).json({ message: 'Dados adicionados ao slider com sucesso.' });
    }
  });
});
app.get('/buscarSubcategorias', (req, res) => {
  const SQL = 'SELECT id_subcategoria, nome_subcategoria, id_categoria_2 FROM subcategorias';

  db.query(SQL, (err, results) => {
    if (err) {
      console.error('Erro na consulta SQL:', err);
      res.status(500).json({ error: 'Erro ao buscar subcategorias' });
    } else {
      res.status(200).json(results);
    }
  });
});
app.post('/adicionarSubcategoria', (req, res) => {
  const { nome_subcategoria, id_categoria_2, id_subcategoria } = req.body;

  if (!nome_subcategoria || !id_categoria_2 || !id_subcategoria) {
    return res.status(400).json({ error: 'Nome da subcategoria, ID da categoria e ID da subcategoria são obrigatórios.' });
  }

  const SQL = 'INSERT INTO subcategorias (nome_subcategoria, id_categoria_2, id_subcategoria) VALUES (?, ?, ?)';

  db.query(SQL, [nome_subcategoria, id_categoria_2, id_subcategoria], (err, result) => {
    if (err) {
      console.error('Erro ao adicionar à subcategoria:', err);
      res.status(500).json({ error: 'Erro ao adicionar à subcategoria' });
    } else {
      res.status(200).json({ message: 'Dados adicionados à subcategoria com sucesso' });
    }
  });
});


app.delete('/deleteSubcategoria/:id_subcategoria', (req, res) => {
  const { id_subcategoria } = req.params;

  const SQL = 'DELETE FROM subcategorias WHERE id_subcategoria = ?';

  db.query(SQL, [id_subcategoria], (err, result) => {
    if (err) {
      console.error('Erro ao excluir da subcategoria:', err);
      res.status(500).json({ error: 'Erro ao excluir da subcategoria' });
    } else {
      res.status(200).json({ message: 'Dados excluídos da subcategoria com sucesso' });
    }
  });
});

app.get('/buscarCategorias', (req, res) => {
  const SQL = 'SELECT id_categoria, nome_categoria FROM categorias';

  db.query(SQL, (err, results) => {
    if (err) {
      console.error('Erro na consulta SQL:', err);
      res.status(500).json({ error: 'Erro ao buscar categorias' });
    } else {
      res.status(200).json(results);
    }
  });
});

app.post('/adicionarCategoria', (req, res) => {
  const { id_categoria, nome_categoria } = req.body;
  const SQL = 'INSERT INTO categorias (id_categoria, nome_categoria) VALUES (?, ?)';
  
  db.query(SQL, [id_categoria, nome_categoria], (err, results) => {
    if (err) {
      console.error('Erro na consulta SQL:', err);
      res.status(500).json({ error: 'Erro ao adicionar categoria' });
    } else {
      res.status(200).json({ message: 'Categoria adicionada com sucesso' });
    }
  });
});

app.delete('/excluirCategoria/:id', (req, res) => {
  const categoriaId = req.params.id;
  const SQL = 'DELETE FROM categorias WHERE id_categoria = ?';
  
  db.query(SQL, categoriaId, (err, results) => {
    if (err) {
      console.error('Erro na consulta SQL:', err);
      res.status(500).json({ error: 'Erro ao excluir categoria' });
    } else {
      res.status(200).json({ message: 'Categoria excluída com sucesso' });
    }
  });
});

app.get('/buscarRedeSocial', (req, res) => {
  const SQL = 'Select * FROM rede_social';

  db.query(SQL, (err, results) => {
    if (err) {
      console.error('Erro na consulta SQL:', err);
      res.status(500).json({ error: 'Erro ao buscar redes sociais' });
    } else {
      res.status(200).json(results);
    }
  });
});


app.post("/registroProduto", (req,res)=>{
  const {id_rede_social} = req.body;
  const {nome_rede_social} = req.body;
  const  {link_rede_social} = req.body;
 
 let SQL = "INSERT INTO rede_social (id_rede_social, nome_rede_social) VALUES(?,?,?)";
 // mandar pro banco
 db.query(SQL, [id_rede_social, nome_rede_social, link_rede_social], (err, result)=>{
 console.log(err);
 }
 )
 });