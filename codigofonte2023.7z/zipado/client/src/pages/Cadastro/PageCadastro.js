import React from "react";
import Header from "../../components/Header/Header.js";
import Footer from "../../components/Footer/Footer.js";
import Cadastro from "../../components/Cadastro/Cadastro.js";
function PageCadastro() {
  return (
    <div>
      <Header />
    <Cadastro/>
      <Footer />
    </div>
  );
}

export default PageCadastro;
