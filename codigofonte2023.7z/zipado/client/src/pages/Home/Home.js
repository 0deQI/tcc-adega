import React from "react";
import Header from "../../components/Header/Header.js";
import Footer from "../../components/Footer/Footer.js";
import Carrossel from "../../components/Carrossel/Carrossel.js";
import ImageSlider from "../../components/ImageSlider/ImageSlider.js";
import { SliderData } from "../../components/ImageSlider/sliderData.js";
import PedidoPersonalizado from "../../components/PedidoPersonalizado/PedidoPersonalizado.js";
import Carrossel2 from "../../components/Carrossel/Carrossel2.js";
import Banner from "../../components/Banner/Banner.js";
import Grid from "../../components/Grid/Grid.js";
function Home() {
  return (
    <div>
      <Header />
      <div className="min-h-screen">
        <ImageSlider slides={SliderData} />
        <Carrossel />
        <Banner />
        <Carrossel2 />
        <PedidoPersonalizado />
        <Grid/>
      </div>
      <Footer />
    </div>
  );
}

export default Home;
