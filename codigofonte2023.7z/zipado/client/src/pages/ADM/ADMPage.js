import React from "react";
import Header from "../../components/Header/Header.js";
import Footer from "../../components/Footer/Footer.js";
import ADM from "../../components/ADM/ADM.js";

function ADMPage() {
  return (
    <div>
      <Header />
      <div className="min-h-screen">


     <ADM/>
      </div>
      <Footer />
    </div>
  );
}

export default ADMPage;
