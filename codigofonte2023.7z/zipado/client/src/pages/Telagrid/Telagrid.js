import React from 'react';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import Grid from '../../components/Grid/Grid';
import { useParams } from 'react-router-dom';

function TelaGrid() {
  const { categoria } = useParams();

  return (
    <div>
      <Header />
      <div className="min-h-screen">
        <Grid categoria={categoria} /> 
      </div>
      <Footer />
    </div>
  );
}

export default TelaGrid;
