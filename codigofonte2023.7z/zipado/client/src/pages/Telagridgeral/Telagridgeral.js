import React from 'react';
import { useLocation } from 'react-router-dom'; // Importe useLocation

import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import GridGeral from '../../components/Grid/GridGeral';

function Telagridgeral() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const searchTerm = searchParams.get('term') || '';

  return (
    <div>
      <Header />
      <div className="min-h-screen">
        <GridGeral searchTerm={searchTerm} />
      </div>
      <Footer />
    </div>
  );
}

export default Telagridgeral;
