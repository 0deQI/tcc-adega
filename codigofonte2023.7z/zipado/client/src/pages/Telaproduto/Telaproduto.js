import React from "react";
import Header from "../../components/Header/Header.js";
import Footer from "../../components/Footer/Footer.js";
import Detalhesproduto from "../../components/Detalhesproduto/Detalhesproduto.js";

function Telaproduto() {
  return (
    <div>
      <Header />
      <div className="min-h-screen">
        <Detalhesproduto />
      </div>
      <Footer />
    </div>
  );
}

export default Telaproduto;
