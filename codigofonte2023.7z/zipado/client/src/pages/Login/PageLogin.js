import React from "react";
import Header from "../../components/Header/Header.js";
import Footer from "../../components/Footer/Footer.js";
import Login from "../../components/Login/Login.js";
function PageLogin() {
  return (
    <div>
      <Header />
    <Login/>
      <Footer />
    </div>
  );
}

export default PageLogin;
