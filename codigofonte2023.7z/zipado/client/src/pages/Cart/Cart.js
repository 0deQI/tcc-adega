import React from "react";
import Header from "../../components/Header/Header.js";
import Footer from "../../components/Footer/Footer.js";
import Carrinho from "../../components/Carrinho/Carrinho.js";

function Cart() {
  return (
    <div>
      <Header />
      <div className="min-h-screen">


        <Carrinho/>
      </div>
      <Footer />
    </div>
  );
}

export default Cart;
