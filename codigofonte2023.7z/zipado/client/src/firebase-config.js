import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';


const firebaseConfig = {
    apiKey: "AIzaSyAMHBsEL90ZHl5QakzNGqmEAD_4di-cx5w",
    authDomain: "teste-projeto-9be49.firebaseapp.com",
    projectId: "teste-projeto-9be49",
    storageBucket: "teste-projeto-9be49.appspot.com",
    messagingSenderId: "505700865552",
    appId: "1:505700865552:web:3de6fab1c8354e4d485c95",
    measurementId: "G-NWXLR77EKE"
  };
  
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

  function Cadastrar(){
    var auth = null;

    firebase.auth().createUserwithEmailAndPassword(document.getElementById("email").value,
    document.getElementById("password").value)
    .then(function (user) {
alert("Dados cadastrados com sucesso")
auth = user;

document.getElementById("email").value = ' '
document.getElementById("senha").value = ' '
    }).cath(function(error) {

        alert("FALHA")
    })
  }