import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home/Home";
import Cart from "./pages/Cart/Cart";
import Telaproduto from "./pages/Telaproduto/Telaproduto";
import Telagrid from "./pages/Telagrid/Telagrid";
import Telagridgeral from "./pages/Telagridgeral/Telagridgeral";
import PageCadastro from "./pages/Cadastro/PageCadastro";
import PageLogin from "./pages/Login/PageLogin";
import ADM from './components/ADM/ADM';
import Login from './components/Login/Login';
import DetalhesDoProduto from "./components/Detalhesproduto/Detalhesproduto";
import ADMPage from "./pages/ADM/ADMPage";

function App() {
  const [idCliente, setIdCliente] = useState(6);

  const handleLogin = (idCliente) => {
    setIdCliente(idCliente);
  };

  return (
    <Router>
      <div className="min-h-screen bg-slate-80">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cart" element={<Cart />} />
          <Route
            path="/products/:productId"
            element={<Telaproduto idCliente={idCliente} />}
          />
          <Route path="/ADMpage2232324423" element={<ADMPage/>}> </Route>
          <Route path="/telagrid/:categoria" element={<Telagrid />} />
          <Route path="/search" element={<Telagridgeral />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
