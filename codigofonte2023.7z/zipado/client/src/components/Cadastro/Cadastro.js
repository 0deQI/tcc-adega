import React, { useState } from "react";
import Axios from "axios";
import { useCreateUserWithEmailAndPassword } from "react-firebase-hooks/auth";
import { auth } from "../services/firebaseConfig";

function Cadastro() {
  const [values, setValues] = useState({});
  const handleChangeValues = (value) => {
    setValues((prevValue) => ({
      ...prevValue,
      [value.target.name]: value.target.value,
    }));
  };

  const [telefone, setTelefone] = useState("");
  const [telefoneWarning, setTelefoneWarning] = useState("");

  const [errorField, setErrorField] = useState(""); // controla qual campo causou o erro

  const [cpf, setCpf] = useState("");
  const [cpfWarning, setCpfWarning] = useState("");

  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [showRegistrationForm, setShowRegistrationForm] = useState(true);
  const [registrationError, setRegistrationError] = useState("");

  const [email, setEmail] = useState("");
  const [emailWarning, setEmailWarning] = useState("");
  const [password, setPassword] = useState("");
  const [
    createUserWithEmailAndPassword,
    user,
    loading,
    error,
  ] = useCreateUserWithEmailAndPassword(auth);

  async function handleSignOut(e) {
    e.preventDefault();

    // 11 dígitos
    if (cpf.length !== 11) {
      setCpfWarning("CPF deve ter 11 dígitos");
      setErrorField("cpf");
    } else if (!/^\d+$/.test(cpf)) {
      setCpfWarning("Digite apenas números");
      setErrorField("cpf");
    } else if (password.length < 8) {
      setRegistrationError("A senha deve ter pelo menos 8 caracteres.");
    } else {
      try {
        // verifica se o CPF é válido ANTES de criar o usuário
        await Axios.post("http://localhost:3001/register", {
          id_cliente: values.id_cliente,
          nome_cliente: values.nome_cliente,
          email_cliente: email,
          senha_cliente: password,
          endereco_cliente: values.endereco_cliente,
          telefone_cliente: values.telefone_cliente,
        });

        const userCredential = await createUserWithEmailAndPassword(
          email,
          password
        );

        // mostra usuário criado com sucesso
        setRegistrationSuccess(true);
        setShowRegistrationForm(false);
        // Limpa quaisquer mensagens de erro restantes
        setRegistrationError("");
      } catch (error) {
        // se der erro
        console.error(error);
        setRegistrationError("Ocorreu um erro durante o cadastro.");
      }
    }
  }

  if (loading) {
    return <p className="text-black">carregando...</p>;
  }

  return (
    <div className="container mx-auto mt-8 w-96">
      <h2 className="text-2xl font-semibold mb-4 text-black">
        Cadastro de Cliente
      </h2>
      {registrationSuccess && (
        <div className="text-green-500">Registro completado com sucesso.</div>
      )}
      {registrationError && !registrationSuccess && (
        <div className={`text-red-500 ${errorField === "email" && "visible"}`}>
          {registrationError}
        </div>
      )}
      {showRegistrationForm && (
        <form>
          <div className="mb-4 w-1/2">
            <label htmlFor="cpf" className="block text-black">
              CPF:
            </label>
            <input
              type="text"
              name="id_cliente"
              placeholder="CPF"
              className={`border border-gray-400 p-2 rounded w-full 
                ${errorField === "cpf" && cpf.length !== 11 ? "border-red-500" : ""}`}
              required
              value={cpf}
              onChange={(e) => {
                const value = e.target.value;
                setCpf(value);
                handleChangeValues(e);

                if (value.length !== 11) {
                  setCpfWarning("CPF deve ter 11 dígitos");
                  setErrorField("cpf");
                } else {
                  setCpfWarning("");
                }

                if (!/^\d+$/.test(value)) {
                  setCpfWarning("Digite apenas números");
                  setErrorField("cpf");
                } else {
                  setCpfWarning("");
                }
              }}
              style={{ color: "black" }}
            />
            <p className={`text-red-500 ${errorField === "cpf" && "visible"}`}>
              {cpfWarning}
            </p>

            <label htmlFor="name" className="block text-black">
              Nome:
            </label>
            <input
              type="text"
              name="nome_cliente"
              placeholder="Nome"
              className="border border-gray-400 p-2 rounded w-full"
              required
              onChange={handleChangeValues}
              style={{ color: "black" }}
            />

            <label htmlFor="email" className="block text-black">
              Email:
            </label>
            <input
              type="text"
              name="email_cliente"
              placeholder="Email"
              className={`border border-gray-400 p-2 rounded w-full 
                ${errorField === "email" && !/^(.+)@(gmail\.com|hotmail\.com)$/.test(email) ? "border-red-500" : ""}`}
              required
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                handleChangeValues(e);

                if (!/^(.+)@(gmail\.com|hotmail\.com)$/.test(e.target.value)) {
                  setEmailWarning("Email deve terminar com @gmail.com ou @hotmail.com");
                  setErrorField("email");
                } else {
                  setEmailWarning("");
                }
              }}
              style={{ color: "black" }}
            />
            <p className={`text-red-500 ${errorField === "email" && "visible"}`}>
              {emailWarning}
            </p>

            <label htmlFor="password" className="block text-black">
              Senha:
            </label>
            <input
              type="password"
              name="senha_cliente"
              placeholder="Senha"
              className="border border-gray-400 p-2 rounded w-full"
              required
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                handleChangeValues(e);
              }}
              style={{ color: "black" }}
            />

            <label htmlFor="endereco" className="block text-black">
              Endereço:
            </label>
            <input
              type="text"
              name="endereco_cliente"
              placeholder="Endereço"
              className="border border-gray-400 p-2 rounded w-full"
              required
              onChange={handleChangeValues}
              style={{ color: "black" }}
            />

            <label htmlFor="telefone" className="block text-black">
              Telefone:
            </label>
            <input
              type="text"
              name="telefone_cliente"
              placeholder="Telefone"
              className={`border border-gray-400 p-2 rounded w-full 
                ${errorField === "telefone" && !/^\d+$/.test(telefone) ? "border-red-500" : ""}`}
              required
              value={telefone}
              onChange={(e) => {
                const value = e.target.value;
                setTelefone(value);
                handleChangeValues(e);

                if (!/^\d+$/.test(value)) {
                  setTelefoneWarning("Digite apenas números");
                  setErrorField("telefone");
                } else {
                  setTelefoneWarning("");
                }
              }}
              style={{ color: "black" }}
            />
            <p className={`text-red-500 ${errorField === "telefone" && "visible"}`}>
              {telefoneWarning}
            </p>
            <button
              className="block text-black"
              type="button"
              onClick={handleSignOut}
            >
              Cadastrar
            </button>
          </div>
        </form>
      )}
      {!showRegistrationForm && (
        <button
          className="block text-black"
          onClick={() => setShowRegistrationForm(true)}
        >
          Fechar
        </button>
      )}
    </div>
  );
}

export default Cadastro;