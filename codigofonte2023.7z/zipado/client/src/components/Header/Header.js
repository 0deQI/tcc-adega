import React, { useState, useRef, useEffect } from "react";

import Navmenu from "../../components/Navmenu/Navmenu";

import Modal from "../../components/Modal/Modal";

import Cadastro from '../../components/Cadastro/Cadastro'

import Login from '../../components/Login/Login'

import { ReactComponent as Logo } from '../Header/logo.svg'

import { Link, useNavigate } from "react-router-dom";

 

function Header() {

  const [isSearchExpanded, setIsSearchExpanded] = useState(false);

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const searchInputRef = useRef(null);

  const [searchTerm, setSearchTerm] = useState("");

  const [isModalOpen, setIsModalOpen] = useState(false);

  const [isCadastroModalOpen, setIsCadastroModalOpen] = useState(false);

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const [loginMessage, setLoginMessage] = useState(""); // mensagem de login

 

  const handleLoginSuccess = () => {

    setIsLoggedIn(true);

    setLoginMessage("Conectado"); // define a mensagem de login como "Conectado" quando o login for bem-sucedido

    closeModal();

  };

 

  const handleLogout = () => {

    setIsLoggedIn(false);

    setLoginMessage(""); // limpa a mensagem de login ao desconectar

    // alterar essa página dps

    navigate("/login");

  };

 

  const handleSearchToggle = () => {

    setIsSearchExpanded(!isSearchExpanded);

 

    if (!isSearchExpanded) {

      setTimeout(() => {

        searchInputRef.current.focus();

      }, 0);

    }

  };

 

  const navigate = useNavigate();

 

  const openCadastroModal = () => {

    setIsCadastroModalOpen(true);

  };

 

  const handleDropdownToggle = () => {

    setIsDropdownOpen(!isDropdownOpen);

  };

 

  const closeCadastroModal = () => {

    setIsCadastroModalOpen(false);

  };

 

  const handleSearchSubmit = () => {

    if (searchTerm.trim() !== "") {

      navigate(`/search?term=${searchTerm}`);

    }

  };

 

  const openModal = () => {

    setIsModalOpen(true);

  };

 

  const closeModal = () => {

    setIsModalOpen(false);

  };

 

  return (

    <div className="bg-slate-80 z-10">

      <header className="bg-black text-white sticky top-0">

        <section className="sm:hidden">

          <h1 className="text-2xl font-medium w-screen/2">

            <Link to="/">

              <a></a>

              <Logo className="w-full"></Logo>

            </Link>

          </h1>

        </section>

        <section className="max-w-screen mx-auto p-3 flex justify-between items-center">

          <h1 className="text-2xl font-medium hidden sm:block">

            <Link to="/">

            <Logo className="w-full"></Logo>

            </Link>

          </h1>

 

          <div className="flex justify-center align-center ml-auto"> {/* Use ml-auto para mover os botões para a direita */}

            <div className="relative self-center">

              <input

                type="text"

                placeholder=""

                className="h-6 w-full rounded text-black sm:h-8 sm:w-80 text-2xl

                ml-15 mr-10 border-6 border-transparent"

                ref={searchInputRef}

                value={searchTerm}

                onChange={(e) => setSearchTerm(e.target.value)}

                onKeyPress={(e) => {

                  if (e.key === "Enter") {

                    handleSearchSubmit();

                  }

                }}

              />

              <i className="fas fa-search absolute right-5 top-2.5 text-gray-400 hidden sm:block" onClick={handleSearchSubmit}></i>

            </div>

 

 

            <button

              id="bars-open-button"

              className="text-3xl sm:hidden focus:outline-none mr-4 "

              onClick={handleDropdownToggle}

            >

              <i className="fas fa-bars ml-10 text-3xl sm:hidden focus:outline-none hover:opacity-90"></i>

            </button>

 

            <button

              id="cart-open-button"

              className="text-3xl hidden sm:block focus:outline-none mr-4"

            >

              <Link to="/Cart">

                <i className="fas fa-cart-shopping text-white hover:opacity-90"></i>

              </Link>

            </button>

            <Modal isOpen={isModalOpen} onClose={closeModal}>

              <Login openCadastroModal={openCadastroModal} handleLoginSuccess={handleLoginSuccess} />

            </Modal>

 

            <Modal isOpen={isCadastroModalOpen} onClose={closeCadastroModal}>

              <button className="absolute top-2 right-2 text-gray-600" onClick={closeCadastroModal}>

                <i className="fas fa-times"></i>

              </button>

              <Cadastro />

            </Modal>

 

            {/* responsacel por mostrar dados cadastrados e opção de deslogar quando isLoggedIn for true */}

            {isLoggedIn ? (

              <div className="flex items-center">

                <p className="text-white">{loginMessage}</p>

                <button onClick={handleLogout} className="text-white ml-4">

                  Desconectar

                </button>

              </div>

            ) : (

              <button

                onClick={openModal}

                id="user-open-button"

                className="text-3xl hidden sm:block focus:outline-none"

              >

                <i className="fas fa-user text-white hover:opacity-90"></i>

              </button>

            )}

          </div>

        </section>

 

        <Navmenu />

      </header>

 

      <div

        className={`${

          isDropdownOpen ? "block" : "hidden"

        } sm:hidden absolute flex right-0 flex-col flex-start h-1/6 w-1/3 bg-black z-10 rounded-b-lg justify-center top-15`}

      >

        <button className="h-10 font-medium text-white">

          Usuário <i className="fas fa-user text-white hover:opacity-90"></i>

        </button>

        <hr class="w-4/5 h-px mx-auto my-1 bg-white border-0 rounded md:my-10"></hr>

        <button className=" h-10 font-medium text-white">

          <Link to="/Cart">

            Carrinho

            <i className="fas fa-cart-shopping text-white hover:opacity-90"></i>

          </Link>

        </button>

      </div>

    </div>

  );

}

 

export default Header;