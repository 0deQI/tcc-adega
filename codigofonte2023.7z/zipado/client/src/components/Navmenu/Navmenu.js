import React from 'react';
import { Link } from 'react-router-dom';

function Navmenu() {
    return (
        <div className="sticky top-0 hidden sm:flex justify-between items-center bg-zinc-100 w-full">
            <section className="mx-auto p-3 flex justify-between items-center">
                <nav className="text-black border-black flex-shrink">



                    <Link to="/telagrid/9" className="mx-auto">
                        Cervejas
                    </Link>



                    <span className="border-l mx-2 h-4 border-black"></span>
                    <Link to="/telagrid/11" className="mx-auto">
                        Vinhos
                    </Link>


                    <span className="border-l mx-2 h-4 border-black"></span>
                    <Link to="/telagrid/2" className="mx-auto">
                        Cachaças
                    </Link>



                    <span className="border-l mx-2 h-4 border-black"></span>
                    <Link to="/telagrid/1" className="mx-auto">
                        Whiskys
                    </Link>


                    <span className="border-l mx-2 h-4 border-black"></span>
                    <Link to="/telagrid/3" className="mx-auto">
                        Vodkas
                    </Link>

                    <span className="border-l mx-2 h-4 border-black"></span>
                    <Link to="/telagrid/10" className="mx-auto">
                        Engradados          </Link>






                </nav>
            </section>
        </div>
    );
}

export default Navmenu;