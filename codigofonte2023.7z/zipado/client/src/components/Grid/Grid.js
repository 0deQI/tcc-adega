import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { adicionarAoCarrinho } from '../Login/Login';  

function Grid() {
  const [listProdutos, setListProdutos] = useState([]);
  const { categoria } = useParams();
  const initialIdCliente = localStorage.getItem('id_cliente');
  const [idCliente, setIdCliente] = useState(initialIdCliente || null);
  const { productId } = useParams();
  const [produtoAtual, setProdutoAtual] = useState(null);
  const [setIdClienteMessage] = useState('');
  const [quantidade, setQuantidade] = useState(1);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("http://localhost:3001/getProdutos")
      .then((response) => response.json())
      .then((data) => {
        const produto = data.find((prod) => prod.id_produto === parseInt(productId));
        setProdutoAtual(produto);
      })
      .catch((error) => {
        console.error("Erro ao buscar dados do produto:", error);
      });
  
    Axios.get('http://localhost:3001/getProdutos')
      .then((response) => {
        const produtosFiltrados = response.data.filter(
          (item) => item.id_subcategoria_2 === parseInt(categoria)
        );
        setListProdutos(produtosFiltrados);
      })
      .catch((error) => {
        console.error(error);
      });
  }, [productId, categoria]);
  

  return (
    <div className="w-full min-h-10vh text-gray-900 flex justify-center items-center mt-5">
      <div style={{ maxWidth: '80vw',  }}>
        <div className="flex justify-center align-center">
          <h2 className="p-4 text-2xl font-semibold">
            {categoria === '9' ? 'Cervejas' :
             categoria === '11' ? 'Vinhos' :
             categoria === '2' ? 'Cachaças' :
             categoria === '1' ? 'Whiskys' :
             categoria === '3' ? 'Vodkas' :
             categoria === '10' ? 'Engradados' : ''}
          </h2>
        </div>
        <div className="flex bg-white rounded-md h-420px" style={{ scrollBehavior: 'smooth' }}>
          <div className="flex flex-wrap w-screen">
            {listProdutos.map((item) => {
              const { id_produto, nome_produto, valor_produto, imagem_produto } = item;
              return (
                <div key={id_produto} className="w-1/3 sm:w-1/5 h-70 p-4  mt-4" >
                  <Link to={`/products/${id_produto}`} key={id_produto}>
                    <div className="bg-gray-0 h-56 rounded ">
                      
                      <img className="w-full h-40 object-contain" src={imagem_produto} alt={nome_produto} />
                      <p className='text-center text-[#1e1e1e] rounded-[10px] text-xs sm:text-xs font-serif font-normal my-0'>
                          {nome_produto}</p>
                      
                    </div>
                    
                  </Link>
                  <p className=' text-center text-[#1e1e1e] rounded-[10px] text-xs sm:text-xl sm:my-7  font-arial font-semibold'>
                      R$ {valor_produto}{' '}
                      <button
  onClick={() => {
    adicionarAoCarrinho(
      idCliente,
      { id_produto },
      quantidade,
      setIdClienteMessage,
      setError
    );
  }}
  className="z-50 cursor-pointer h-6 mt-3 rounded-full bg-black text-white text-base font-medium font-sans w-10 ml-2"
>
  <i className="fa-solid fa-cart-plus"></i>
</button>{' '}
                    </p>
               {/*   <div className="flex justify-center "> */} 
                {/*     <button */} 
                   {/*    className="cursor-pointer h-8 mt-4 rounded-full bg-black text-white text-base font-medium font-sans w-16" >*/} 
                  {/*     <i className="fa-solid fa-cart-plus"></i>*/} 
                   {/*  </button> */} 
                  {/*   </div> */} 
              </div>
              );
            })} 
          </div>
        </div>
      </div>
    </div>
  );
}

export default Grid;
