import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { adicionarAoCarrinho } from '../Login/Login';


function GridGeral({ searchTerm }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const initialIdCliente = localStorage.getItem('id_cliente');
  const [idCliente, setIdCliente] = useState(initialIdCliente || null);
  const { productId } = useParams();
  const [produtoAtual, setProdutoAtual] = useState(null);
  const [setIdClienteMessage] = useState('');
  const [quantidade, setQuantidade] = useState(1);
  const [error, setError] = useState(null);

  useEffect(() => {

    axios
      .get(`http://localhost:3001/buscarProduto?nome=${searchTerm}`)
      .then((response) => {
        setProducts(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Erro ao buscar produtos:', error);
        setLoading(false);
      });
  }, [searchTerm]);

  if (loading) {
    return <p>Carregando...</p>;
  }

  const totalProducts = products.length;

  return (
    <div className='w-full min-h-10vh text-gray-900 flex justify-center items-center  mt-5'>
      <div style={{ maxWidth: '80vw', }}>
        <div className='font-medium text-lg text-right'>
          {searchTerm && (
            <p>
              <span style={{
                textDecoration: 'underline',
                textDecorationColor: 'pink',
                textDecorationThickness: '4px',
                textDecorationOffset: '10px'
              }}>
                {totalProducts} itens ㅤㅤㅤㅤㅤ Resultado da pesquisa
              </span>
            </p>
          )}
        </div>
        {totalProducts === 0 ? (
          <p>Nenhum produto encontrado.</p>
        ) : (
          <div className='flex bg-white rounded-md h-420px' style={{ scrollBehavior: 'smooth' }}>
            <div className='flex flex-wrap w-screen '>
              {products.map((product) => {
                const { id_produto, nome_produto, valor_produto, imagem_produto } = product;
                return (
                  <div key={id_produto} className='w-1/3 sm:w-1/5 h-70 p-4  mt-4'>
                    <Link to={`/products/${id_produto}`} key={id_produto}>
                      <div className='bg-gray-0 h-56 rounded '>
                        <img className='w-full h-40 object-contain' src={imagem_produto} alt={nome_produto} />
                        <p className=' break-normal block text-center text-[#1e1e1e] rounded-[10px] text-xs sm:text-base font-serif font-normal my-0'>
                          {nome_produto}
                        </p>
                      </div>
                    </Link>
                    <p className='block text-center text-[#1e1e1e] rounded-[10px] text-xs sm:text-xl  font-arial font-semibold'>
                      R$ {valor_produto}{' '}
                      <button
                        onClick={() => {
                          adicionarAoCarrinho(
                            idCliente,
                            { id_produto },
                            quantidade,
                            setIdClienteMessage,
                            setError
                          );
                        }}
                        className="z-50 cursor-pointer h-6 mt-3 rounded-full bg-black text-white text-base font-medium font-sans w-10 ml-2"
                      >
                        <i className="fa-solid fa-cart-plus"></i>
                      </button>{' '}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default GridGeral;
