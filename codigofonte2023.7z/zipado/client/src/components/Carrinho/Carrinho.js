import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import jsPDF from 'jspdf';
import axios from 'axios'; 

const useFetchCartItems = (idCliente, setCartItems) => {
  useEffect(() => {
    fetch(`http://localhost:3001/getItensCarrinho?id_cliente=${idCliente}`)
      .then((response) => response.json())
      .then((data) => setCartItems(data))
      .catch((error) => console.log(error));
  }, [idCliente]);
};

function Carrinho() {
  const handleGeneratePDF = () => {
    const doc = new jsPDF();
    doc.text('Resumo do Carrinho', 10, 10);

    if (idCliente) {
      doc.text(`Usuário: ${idCliente}`, 10, 20);
    }

    let yPos = 50;

    for (const item of cartItems) {
      doc.text(`Nome do Produto: ${item.nome_produto}`, 10, yPos);
      doc.text(`Quantidade: ${item.quantidade}`, 10, yPos + 10);
      doc.text(`Preço: R$ ${item.valor_produto}`, 10, yPos + 20);
      yPos += 30;
    }

    doc.text(`Subtotal: R$ ${calcularSubtotal()}`, 10, yPos + 20);

    doc.save('carrinho.pdf');
  };

  const initialIdCliente = localStorage.getItem('id_cliente');
  const [idCliente, setIdCliente] = useState(initialIdCliente || null);

  const [cartItems, setCartItems] = useState([]);

  useFetchCartItems(idCliente, setCartItems);

  const calcularSubtotal = () => {
    let subtotal = 0;
    for (const item of cartItems) {
      subtotal += item.valor_produto * item.quantidade;
    }
    return subtotal.toFixed(2);
  };

  const handleQuantityChange = (id_itens_carrinho, newQuantity) => {
    if (newQuantity <= 0) {
      fetch(`http://localhost:3001/removeFromCart/${id_itens_carrinho}`, {
        method: 'DELETE',
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            console.log('Produto removido do carrinho e do banco de dados com sucesso.');
            const updatedCart = cartItems.filter((item) => item.id_itens_carrinho !== id_itens_carrinho);
            setCartItems(updatedCart);
          } else {
            console.log('Erro ao remover o produto do carrinho e do banco de dados.');
          }
        })
        .catch((error) => console.log(error));
    } else {
      fetch('http://localhost:3001/updateQuantity', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id_itens_carrinho, newQuantity }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            setCartItems((prevItems) =>
              prevItems.map((item) =>
                item.id_itens_carrinho === id_itens_carrinho ? { ...item, quantidade: newQuantity } : item
              )
            );
          } else {
            console.log('Erro ao atualizar a quantidade.');
          }
        })
        .catch((error) => console.log(error));
    }
  };

  // Função para buscar os dados do cliente
  const fetchClienteData = () => {
    axios
      .get(`http://localhost:3001/getCliente?id_cliente=${idCliente}`)
      .then((response) => {
        const clienteData = response.data; // Os dados do cliente
        console.log('Dados do cliente:', clienteData);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    if (idCliente) {
      fetchClienteData(); // Chama a função para buscar os dados do cliente quando o idCliente é definido.
    }
  }, [idCliente]);

  return (
    <div className="text-center bg-stone-100">
      <div className="container-carrinho bg-white w-4/5 mx-auto mt-auto pb-28 flex-column sm:flex ">
        <div className="container1 bg-slate-100 sm:w-2/5 mx-auto mt-10">
          <div className="text-center mb-3 ">
            <span className="text-2xl font-serif ">Carrinho</span>
          </div>
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center">
              <div>
                <i className="fas fa-thin fa-cart-shopping text-black text-6xl"></i>
              </div>
              <p className="mt-5 font-sans">Seu carrinho está vazio.</p>
              <Link to="/search">
                <button className="bg-black text-white h-12 mt-2" style={{ padding: "10px 20px" }}>
                  CONTINUE COMPRANDO
                </button>
              </Link>
            </div>
          ) : (
            cartItems.map((item) => (
              <div key={item.id_itens_carrinho} className="flex flex-col items-center justify-center mt-10">
                <p>{item.nome_produto}</p>
                {item.imagem_produto && (
                  <img className="w-full h-40 object-contain bg-white rounded-md" src={item.imagem_produto} alt={item.nome_produto} style={{ maxWidth: "100px" }} />
                )}
                <div className="flex items-center">
                  <button
                    onClick={() => handleQuantityChange(item.id_itens_carrinho, item.quantidade - 1)}
                    className="cursor-pointer border border-black rounded-full px-3 mr-2"
                  >
                    -
                  </button>
                  <p>Quantidade: {item.quantidade}</p>
                  <button
                    onClick={() => handleQuantityChange(item.id_itens_carrinho, item.quantidade + 1)}
                    className="cursor-pointer border border-black rounded-full px-3 ml-2"
                  >
                    +
                  </button>
                </div>
                <p>Preço: R$ {item.valor_produto}</p>
              </div>
            ))
          )}
        </div>
        <div className="container2 bg-slate-100 p-4 sm:w-3/6 h-60 mx-auto w-full mt-10">
          <div className="text-left">
            <span className="text-2xl font-serif">Resumo da compra</span>
          </div>
          <div className="text-left">
            <span className="font-extralight text-lg">Subtotal:</span>
          </div>
          <div className="text-right">
            <span className="text-4xl font-semibold">
              R$ {calcularSubtotal()}
            </span>
          </div>
          <div>
            <button className="bg-black text-white h-12 mt-4" style={{ padding: "10px 20px" }}>
              FINALIZAR COMPRA
            </button>
          </div>
          <div>
            <button onClick={handleGeneratePDF} className="bg-black text-white h-12 mt-4" style={{ padding: "10px 20px" }}>
              Gerar PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Carrinho;
