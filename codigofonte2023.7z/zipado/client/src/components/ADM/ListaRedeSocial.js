import React, { useState, useEffect } from "react";
import Axios from "axios";

function ListaRedeSocial() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    Axios.get("http://localhost:3001/buscarRedeSocial").then((response) => {
      setProducts(response.data);
    });
  }, []);

  return (
    <div className="p-4 bg-pink-200 rounded-md">
      <h3 className="text-xl font-semibold ml-5">Lista de Rede Social</h3>
      <div className="overflow-x-auto">
        <table className="w-full whitespace-nowrap">
          <thead>
            <tr>
              <th className="p-2 bg-pink-300">ID Rede Social</th>
              <th className="p-2 bg-pink-300">Nome Rede Social</th>
              <th className="p-2 bg-pink-300">Link Rede Social</th>
           
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id_rede_social}>
                <td className="p-2">{product.id_rede_social}</td>
                <td className="p-2">{product.nome_rede_social}</td>
                <td className="p-2">{product.link_rede_social}</td>

             
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ListaRedeSocial;
