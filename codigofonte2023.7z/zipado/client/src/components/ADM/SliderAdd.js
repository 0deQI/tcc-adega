import React, { useState } from "react";
import Axios from "axios";

function SliderAdd() {
  const [sliderData, setSliderData] = useState({
    id_slider: "",
    link_slider: "",
  });

  const handleSliderInputChange = (e) => {
    const { name, value } = e.target;
    setSliderData({
      ...sliderData,
      [name]: value,
    });
  };

  const handleAddToSlider = () => {
    Axios.post("http://localhost:3001/adicionarSlider", sliderData)
      .then((response) => {
        console.log(response);
        setSliderData({
          id_slider: "",
          link_slider: "",
        });
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="bg-pink-200 p-4 rounded-md shadow-md">
      <h3 className="text-xl font-bold">Adicionar ao Slider</h3>
      <form className="flex flex-col mt-2">
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="id_slider"
          placeholder="ID do Slider"
          value={sliderData.id_slider}
          onChange={handleSliderInputChange}
        />
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="link_slider"
          placeholder="Link do Slider"
          value={sliderData.link_slider}
          onChange={handleSliderInputChange}
        />
        <button
          className="bg-pink-500 w-72 text-white p-2 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={handleAddToSlider}
        >
          Adicionar ao Slider
        </button>
      </form>
    </div>
  );
}

export default SliderAdd;