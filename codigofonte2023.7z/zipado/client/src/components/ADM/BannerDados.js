import React, { useEffect, useState } from "react";
import Axios from "axios";

function BannerDados() {
  const [bannerData, setBannerData] = useState([]);

  useEffect(() => {
    Axios.get("http://localhost:3001/bannerdados")
      .then((response) => {
        setBannerData(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  return (
    <div className="p-4 bg-pink-200">
      <h1 className="text-2xl font-bold mb-4">Dados da Tabela Banner</h1>
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-pink-300">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              ID do Banner
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase ">
              Link do Banner
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {bannerData.map((banner) => (
            <tr key={banner.id_banner}>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{banner.id_banner}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-gray-900">{banner.link_banner}</div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default BannerDados;
