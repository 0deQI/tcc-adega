import React, { useState, useEffect } from "react";
import Axios from "axios";

function ListaCategorias() {
  const [categorias, setCategorias] = useState([]);

  useEffect(() => {
    Axios.get("http://localhost:3001/buscarCategorias").then((response) => {
      setCategorias(response.data);
    });
  }, []);

  return (
    <div className="p-4 bg-pink-200 rounded-md">
      <h3 className="text-xl font-semibold ml-5">Lista de Categorias</h3>
      <div className="overflow-x-auto">
        <table className="w-full whitespace-nowrap">
          <thead>
            <tr>
              <th className="p-2 bg-pink-300">ID da Categoria</th>
              <th className="p-2 bg-pink-300">Nome da Categoria</th>
            </tr>
          </thead>
          <tbody>
            {categorias.map((categoria) => (
              <tr key={categoria.id_categoria}>
                <td className="p-2">{categoria.id_categoria}</td>
                <td className="p-2">{categoria.nome_categoria}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ListaCategorias;
