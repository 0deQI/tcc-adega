import React, { useState } from "react";
import Axios from "axios";

function SubcategoriaAdd() {
  const [subcategoriaData, setSubcategoriaData] = useState({
    nome_subcategoria: "",
    id_categoria_2: "",
    id_subcategoria: "", 
  });

  const handleSubcategoriaInputChange = (e) => {
    const { name, value } = e.target;
    setSubcategoriaData({
      ...subcategoriaData, 
      [name]: value,
    });
  };

  const handleAddToSubcategoria = () => {
    Axios.post("http://localhost:3001/adicionarSubcategoria", subcategoriaData)
      .then((response) => {
        console.log(response);
        setSubcategoriaData({
          nome_subcategoria: "",
          id_categoria_2: "",
          id_subcategoria: "", 
        });
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="bg-pink-200 p-4 rounded-md shadow-md">
      <h3 className="text-xl font-bold">Adicionar à Subcategoria</h3>
      <form className="flex flex-col mt-2">
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="nome_subcategoria"
          placeholder="Nome da Subcategoria"
          value={subcategoriaData.nome_subcategoria}
          onChange={handleSubcategoriaInputChange}
        />
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="id_categoria_2"
          placeholder="ID da Categoria"
          value={subcategoriaData.id_categoria_2}
          onChange={handleSubcategoriaInputChange}
        />
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="id_subcategoria"
          placeholder="ID da Subcategoria" 
          value={subcategoriaData.id_subcategoria}
          onChange={handleSubcategoriaInputChange}
        />
        <button
          className="bg-pink-500 w-72 text-white p-2 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={handleAddToSubcategoria}
        >
          Adicionar à Subcategoria
        </button>
      </form>
    </div>
  );
}

export default SubcategoriaAdd;