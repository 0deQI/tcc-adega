import React, { useState } from "react";
import Axios from "axios";

function CategoriaDelete() {
  const [deleteCategoriaId, setDeleteCategoriaId] = useState("");

  const handleDeleteCategoria = () => {
    Axios.delete(`http://localhost:3001/excluirCategoria/${deleteCategoriaId}`)
      .then((response) => {
        console.log(response);
        setDeleteCategoriaId("");
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="p-4 bg-pink-200">
      <h3 className="text-xl font-bold">Excluir Categoria</h3>
      <form className="flex flex-col items-left mt-2">
        <input
          className="bg-white w-72 p-2 rounded-md shadow-md focus:ring focus:ring-pink-400"
          type="text"
          name="deleteCategoriaId"
          placeholder="ID da Categoria a Excluir"
          value={deleteCategoriaId}
          onChange={(e) => setDeleteCategoriaId(e.target.value)}
        />
        <button
          className="bg-pink-500 text-white w-72 p-2 mt-3 rounded-md hover-bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={handleDeleteCategoria}
        >
          Excluir Categoria
        </button>
      </form>
    </div>
  );
}

export default CategoriaDelete;
