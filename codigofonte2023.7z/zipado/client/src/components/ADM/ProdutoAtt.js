import React, { useState } from "react";
import Axios from "axios";

function ProdutoAtt() {
  const [values, setValues] = useState({
    updateProductId: "",
    nome_produto: "",
    descricao_produto: "",
    valor_produto: "",
    Marca: "",
    id_categoria_3: "",
    id_subcategoria_2: "",
    id_fornecedor_2: "",
    imagem_produto: "",
  });

  const handleChangeValues = (e) => {
    setValues({
      ...values,
      [e.target.name]: e.target.value,
    });
  };

  const handleUpdateProduct = () => {
    const updatedData = {};

    for (const key in values) {
      if (values[key] !== "") {
        updatedData[key] = values[key];
      }
    }

    Axios.put(`http://localhost:3001/updateProduto/${values.updateProductId}`, updatedData)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="p-4 bg-pink-200">
      <h3 className="text-xl font-bold ml-5">Atualizar Produto</h3>
      <form className="flex flex-col">
        <input
          className="bg-white w-72 p-2 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="updateProductId"
          placeholder="ID_produto"
          value={values.updateProductId}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 mt-3 p-2 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="nome_produto"
          placeholder="Nome"
          value={values.nome_produto}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 mt-3 p-2 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="descricao_produto"
          placeholder="Descrição"
          value={values.descricao_produto}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 mt-3 p-2 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="Marca"
          placeholder="Marca"
          value={values.Marca}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 p-2 mt-3 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="valor_produto"
          placeholder="Preço"
          value={values.valor_produto}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 p-2 mt-3 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="id_categoria_3"
          placeholder="id_categoria"
          value={values.id_categoria_3}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 p-2 mt-3 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="id_subcategoria_2"
          placeholder="id_subcategoria"
          value={values.id_subcategoria_2}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 p-2  mt-3 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="unidade_produto"
          placeholder="unidade_produto"
          value={values.unidade_produto}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 p-2 mt-3 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="id_fornecedor_2"
          placeholder="id_fornecedor"
          value={values.id_fornecedor_2}
          onChange={handleChangeValues}
        />

        <input
          className="bg-white w-72 p-2  mt-3 rounded-md shadow-md focus:ring focus:ring-pink-400 ml-5 mr-5"
          type="text"
          name="imagem_produto"
          placeholder="imagem_link"
          value={values.imagem_produto}
          onChange={handleChangeValues}
        />

        <button
          className="bg-pink-500 w-72 mt-3 text-white p-2 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400 ml-5 mr-5"
          onClick={handleUpdateProduct}
        >
          Atualizar
        </button>
      </form>
    </div>
  );
}

export default ProdutoAtt;
