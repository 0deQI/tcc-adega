import React, { useState } from "react";
import Axios from "axios";

function BannerDelete() {
  const [deleteBannerId, setDeleteBannerId] = useState("");

  const handleDeleteBanner = () => {
    Axios.delete(`http://localhost:3001/excluirBanner/${deleteBannerId}`)
      .then((response) => {
        console.log(response);
        setDeleteBannerId("");
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="p-4 bg-pink-200">
      <h3 className="text-xl font-bold">Excluir Banner</h3>
      <form className="flex flex-col items-left mt-2">
        <input
          className="bg-white w-72 p-2 rounded-md shadow-md focus:ring focus:ring-pink-400"
          type="text"
          name="deleteBannerId"
          placeholder="ID do Banner a Excluir"
          value={deleteBannerId}
          onChange={(e) => setDeleteBannerId(e.target.value)}
        />
        <button
          className="bg-pink-500 text-white  w-72 p-2 mt-3 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={handleDeleteBanner}
        >
          Excluir Banner
        </button>
      </form>
    </div>
  );
}

export default BannerDelete;
