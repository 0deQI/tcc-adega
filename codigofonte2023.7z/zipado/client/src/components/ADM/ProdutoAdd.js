import React, { useState } from "react";
import Axios from "axios";

function ProdutoAdd() {
  const [values, setValues] = useState({
    id_produto: "",
    nome_produto: "",
    descricao_produto: "",
    valor_produto: "",
    Marca: "",
    id_categoria_3: "",
    id_subcategoria_2: "",
    id_fornecedor_2: "",
    imagem_produto: "",
  });

  const handleChangeValues = (e) => {
    setValues({
      ...values,
      [e.target.name]: e.target.value,
    });
  };

  const handleClickButton = () => {
    Axios.post("http://localhost:3001/registroProduto", values).then(
      (response) => {
        console.log(response);
        setValues({
          id_produto: "",
          nome_produto: "",
          descricao_produto: "",
          valor_produto: "",
          Marca: "",
          id_categoria_3: "",
          id_subcategoria_2: "",
          id_fornecedor_2: "",
          imagem_produto: "",
        });
      }
    );
  };

  return (
    <div className= "bg-pink-200 p-4 rounded-md shadow-md">
      <h3 className="ml-5 text-xl font-bold">Cadastrar Produto</h3>
      <form className="flex flex-wrap mt-2 ml-5">
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="id_produto"
          placeholder="Id_produto"
          onChange={handleChangeValues}
          value={values.id_produto}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="nome_produto"
          placeholder="Nome"
          onChange={handleChangeValues}
          value={values.nome_produto}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="descricao_produto"
          placeholder="Descricao"
          onChange={handleChangeValues}
          value={values.descricao_produto}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="Marca"
          placeholder="Marca"
          onChange={handleChangeValues}
          value={values.Marca}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="valor_produto"
          placeholder="Preço"
          onChange={handleChangeValues}
          value={values.valor_produto}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="id_categoria_3"
          placeholder="Id_categoria"
          onChange={handleChangeValues}
          value={values.id_categoria_3}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="id_subcategoria_2"
          placeholder="Id_subcategoria"
          onChange={handleChangeValues}
          value={values.id_subcategoria_2}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="unidade_produto"
          placeholder="unidade_produto"
          onChange={handleChangeValues}
          value={values.unidade_produto}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="id_fornecedor_2"
          placeholder="Id_fornecedor"
          onChange={handleChangeValues}
          value={values.id_fornecedor_2}
        />
        <input
          className="bg-white w-1/3 p-2 rounded-md mr-5 mb-3"
          type="text"
          name="imagem_produto"
          placeholder="Imagem_link"
          onChange={handleChangeValues}
          value={values.imagem_produto}
        />
        <button
          className="bg-pink-500 text-white w-1/3 p-2 rounded-md mr-5 mb-3 hover:bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={() => handleClickButton()}
        >
          Cadastrar
        </button>
      </form>
    </div>
  );
}

export default ProdutoAdd;
