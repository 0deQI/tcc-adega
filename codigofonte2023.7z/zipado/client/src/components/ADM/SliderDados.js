import React, { useState, useEffect } from "react";
import Axios from "axios";

function SliderDados() {
  const [sliderData, setSliderData] = useState([]);

  useEffect(() => {
    Axios.get("http://localhost:3001/getSliderData").then((response) => {
      setSliderData(response.data);
    });
  }, []);

  return (
    <div className="p-4 bg-pink-200 rounded-md">
      <h3 className="text-xl font-semibold ml-5">Slider Data</h3>
      <div className="overflow-x-auto">
        <table className="w-full whitespace-nowrap">
          <thead>
            <tr>
              <th className="p-2 bg-pink-300">ID</th>
              <th className="p-2 bg-pink-300">Link</th>
            </tr>
          </thead>
          <tbody>
            {sliderData.map((item) => (
              <tr key={item.id_slider}>
                <td className="p-2">{item.id_slider}</td>
                <td className="p-2 break-all">
                  <a
                    href={item.link_slider}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    {item.link_slider}
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default SliderDados;
