import React, { useState } from "react";
import Axios from "axios";

function CategoriaAdd() {
  const [categoriaData, setCategoriaData] = useState({
    id_categoria: "",
    nome_categoria: "",
  });

  const handleCategoriaInputChange = (e) => {
    const { name, value } = e.target;
    setCategoriaData({
      ...categoriaData,
      [name]: value,
    });
  };

  const handleAddToCategoria = () => {
    Axios.post("http://localhost:3001/adicionarCategoria", categoriaData)
      .then((response) => {
        console.log(response);
        setCategoriaData({
          id_categoria: "",
          nome_categoria: "",
        });
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="bg-pink-200 p-4 rounded-md shadow-md">
      <h3 className="text-xl font-bold">Adicionar à Categoria</h3>
      <form className="flex flex-col mt-2">
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="id_categoria"
          placeholder="ID da Categoria"
          value={categoriaData.id_categoria}
          onChange={handleCategoriaInputChange}
        />
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="nome_categoria"
          placeholder="Nome da Categoria"
          value={categoriaData.nome_categoria}
          onChange={handleCategoriaInputChange}
        />
        <button
          className="bg-pink-500 w-72 text-white p-2 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={handleAddToCategoria}
        >
          Adicionar à Categoria
        </button>
      </form>
    </div>
  );
}

export default CategoriaAdd;
