import React, { useState } from "react";
import Axios from "axios";

function SliderDelete() {
  const [id_slider, setIdSlider] = useState("");
  const [message, setMessage] = useState("");

  const handleDelete = () => {
    if (!id_slider) {
      setMessage("Por favor, insira um ID de slider válido!");
      return;
    }

    Axios.delete(`http://localhost:3001/api/deleteSlider/${id_slider}`)
      .then(() => {
        setMessage(`Dados do slider com ID ${id_slider} excluídos com sucesso.`);
        setIdSlider("");
      })
      .catch((error) => {
        console.error(error);
        setMessage("Erro ao excluir dados do slider");
      });
  };

  return (
    <div className="bg-pink-200 p-4 rounded-md shadow-md">
      <h3 className="text-xl font-bold mb-4">Excluir Dados do Slider</h3>
      <div className="mb-2">
        <label className="block font-semibold mb-2">ID do Slider:</label>
        <input
          type="number"
          value={id_slider}
          onChange={(e) => setIdSlider(e.target.value)}
          className="w-72 p-2 border rounded-md"
        />
      </div>
      <button
        onClick={handleDelete}
        className="bg-pink-500 text-white p-2 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400"
      >
        Excluir
      </button>
      <p className="mt-4 text-red-600">{message}</p>
    </div>
  );
}

export default SliderDelete;
