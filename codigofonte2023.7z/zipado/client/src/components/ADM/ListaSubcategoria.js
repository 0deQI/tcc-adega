import React, { useState, useEffect } from "react";
import Axios from "axios";

function ListaSubcategoria() {
  const [subcategorias, setSubcategorias] = useState([]);

  useEffect(() => {
    Axios.get("http://localhost:3001/buscarSubcategorias").then((response) => {
      setSubcategorias(response.data);
    });
  }, []);

  return (
    <div className="p-4 bg-pink-200 rounded-md">
      <h3 className="text-xl font-semibold ml-5">Lista de Subcategorias</h3>
      <div className="overflow-x-auto">
        <table className="w-full whitespace-nowrap">
          <thead>
            <tr>
              <th className="p-2 bg-pink-300">ID</th>
              <th className="p-2 bg-pink-300">Nome da Subcategoria</th>
              <th className="p-2 bg-pink-300">ID da Categoria</th>
            </tr>
          </thead>
          <tbody>
            {subcategorias.map((subcategoria) => (
              <tr key={subcategoria.id_subcategoria}>
                <td className="p-2">{subcategoria.id_subcategoria}</td>
                <td className="p-2">{subcategoria.nome_subcategoria}</td>
                <td className="p-2 text-center">{subcategoria.id_categoria_2}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ListaSubcategoria;
