import React, { useState } from "react";
import Axios from "axios";
import ListaProduto from "./ListaProduto";
import BannerAdd from "./BannerAdd";
import BannerDelete from "./BannerDelete";
import ProdutoAdd from "./ProdutoAdd";
import BannerDados from "./BannerDados";
import ProdutoAtt from "./ProdutoAtt";
import ProdutoDelete from "./ProdutoDelete";
import SliderDados from "./SliderDados";
import SliderDelete from "./SliderDelete";
import SliderAtt from "./SliderAtt";
import SliderAdd from "./SliderAdd";
import ListaSubcategoria from "./ListaSubcategoria";
import SubcategoriaAdd from "./SubcategoriaAdd";
import SubcategoriaDelete from "./SubcategoriaDelete";
import ListaCategorias from "./ListaCategorias";
import CategoriaAdd from "./CategoriaAdd";
import CategoriaDelete from "./CategoriaDelete";
import ListaRedeSocial from "./ListaRedeSocial";

function ADM() {
  const [values, setValues] = useState({
    id_produto: "",
    nome_produto: "",
    descricao_produto: "",
    valor_produto: "",
    Marca: "",
    id_categoria_3: "",
    id_subcategoria_2: "",
    id_fornecedor_2: "",
    imagem_produto: "",
  });
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [deleteProductId, setDeleteProductId] = useState("");
  const [updateProductId, setUpdateProductId] = useState("");
  const [isCadastrarVisible, setIsCadastrarVisible] = useState(false);
  const [isBannerVisible, setIsBannerVisible] = useState(false);
  const [isSliderVisible, setIsSliderVisible] = useState(false);
  const [isExcluirVisible, setIsExcluirVisible] = useState(false);
  const [isEditarVisible, setIsEditarVisible] = useState(false);
  const [isListaVisible, setIsListaVisible] = useState(false);
  const [isListaProdutoVisible, setIsListaProdutoVisible] = useState(false);
  const [isSubcategoriaVisible, setIsSubcategoriaVisible] = useState(false);
  const [isCategoriaVisible, setIsCategoriaVisible] = useState(false);

  const handleDropdownToggle = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleChangeValues = (e) => {
    setValues({
      ...values,
      [e.target.name]: e.target.value,
    });
  };

  const handleClickButton = () => {
    Axios.post("http://localhost:3001/registroProduto", values).then(
      (response) => {
        console.log(response);
        setValues({
          id_produto: "",
          nome_produto: "",
          descricao_produto: "",
          valor_produto: "",
          Marca: "",
          id_categoria_3: "",
          id_subcategoria_2: "",
          id_fornecedor_2: "",
          imagem_produto: "",
        });
      }
    );
  };

  const handleDeleteProduct = () => {
    Axios.delete(`http://localhost:3001/deleteProduto/${deleteProductId}`)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleUpdateProduct = () => {
    const updatedData = {};

    for (const key in values) {
      if (values[key] !== "") {
        updatedData[key] = values[key];
      }
    }
    Axios.put(`http://localhost:3001/updateProduto/${updateProductId}`, updatedData)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="min-h-screen bg-slate-80 flex flex-col">
      <div className=" inline-block text-left">
        <button
          onClick={handleDropdownToggle}
          type="button"
          className="inline-flex justify-center w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:border-blue-300 focus:ring focus:ring-blue-200 active:bg-gray-100 active:text-gray-800"
          id="options-menu"
          aria-haspopup="true"
          aria-expanded={isDropdownOpen}
        >
          Opções
          <svg className="-mr-1 ml-2 h-5 w-5" viewBox="0 0 20 20"></svg>
        </button>

        <div
          className={`${
            isDropdownOpen ? "block" : "hidden"
          } origin-top-right absolute right-0 mt-2 w-40 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none`}
        >
          <div
            className="py-1"
            role="menu"
            aria-orientation="vertical"
            aria-labelledby="options-menu"
          >
            <button
              onClick={() => {
                setIsCadastrarVisible(false);
                setIsExcluirVisible(false);
                setIsEditarVisible(true);
                setIsListaProdutoVisible(false);
                setIsBannerVisible(false);
                setIsSliderVisible(false);
                setIsSubcategoriaVisible(false);
                setIsCategoriaVisible(false);
              }}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover.bg-gray-100"
              role="menuitem"
            >
              Produto
            </button>

            <button
              onClick={() => {
                setIsCadastrarVisible(false);
                setIsExcluirVisible(false);
                setIsEditarVisible(false);
                setIsListaProdutoVisible(false);
                setIsBannerVisible(true);
                setIsSliderVisible(false);
                setIsSubcategoriaVisible(false);
                setIsCategoriaVisible(false);
              }}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover.bg-gray-100"
              role="menuitem"
            >
              Banner
            </button>

            <button
              onClick={() => {
                setIsCadastrarVisible(false);
                setIsExcluirVisible(false);
                setIsEditarVisible(false);
                setIsListaProdutoVisible(false);
                setIsBannerVisible(false);
                setIsSliderVisible(true);
                setIsSubcategoriaVisible(false);
                setIsCategoriaVisible(false);
              }}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover.bg-gray-100"
              role="menuitem"
            >
              Slider
            </button>

            <button
              onClick={() => {
                setIsCadastrarVisible(false);
                setIsExcluirVisible(false);
                setIsEditarVisible(false);
                setIsListaProdutoVisible(false);
                setIsBannerVisible(false);
                setIsSliderVisible(false);
                setIsSubcategoriaVisible(true);
                setIsCategoriaVisible(false);
              }}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover.bg-gray-100"
              role="menuitem"
            >
              Subcategoria
            </button>

            <button
              onClick={() => {
                setIsCadastrarVisible(false);
                setIsExcluirVisible(false);
                setIsEditarVisible(false);
                setIsListaProdutoVisible(false);
                setIsBannerVisible(false);
                setIsSliderVisible(false);
                setIsSubcategoriaVisible(false);
                setIsCategoriaVisible(true);
              }}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover.bg-gray-100"
              role="menuitem"
            >
              Categoria
            </button>
          </div>
        </div>
      </div>

      <div className="">
        <div className="flex flex-col">
          {isEditarVisible && <ProdutoAdd />}
          {isEditarVisible && <ProdutoDelete />}
          {isEditarVisible && <ProdutoAtt />}
          {isEditarVisible && <ListaProduto />}
        </div>

        <div className="flex flex-col">
          {isBannerVisible && <BannerAdd />}
          {isBannerVisible && <BannerDelete />}
          {isBannerVisible && <BannerDados />}

          {isSliderVisible && <SliderDados />}
          {isSliderVisible && <SliderDelete />}
          {isSliderVisible && <SliderAtt />}
          {isSliderVisible && <SliderAdd />}

          {isSubcategoriaVisible && <SubcategoriaAdd />}
          {isSubcategoriaVisible && <SubcategoriaDelete />}
          {isSubcategoriaVisible && <ListaSubcategoria />}

          {isCategoriaVisible && <CategoriaAdd />}
          {isCategoriaVisible && <CategoriaDelete />}
          {isCategoriaVisible && <ListaCategorias />}
          <ListaRedeSocial/>
        </div>
      </div>
    </div>
  );
}

export default ADM;
