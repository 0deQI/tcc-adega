import React, { useState } from "react";
import Axios from "axios";

function SubcategoriaDelete() {
  const [deleteSubcategoriaId, setDeleteSubcategoriaId] = useState("");

  const handleDeleteSubcategoria = () => {
    Axios.delete(`http://localhost:3001/deleteSubcategoria/${deleteSubcategoriaId}`)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div className="bg-pink-200 p-4 rounded-md">
      <h3 className="text-xl font-bold">Excluir da Subcategoria</h3>
      <form className="flex flex-col mt-2">
        <input
          className="bg-white w-72 p-2 rounded-md mb-3"
          type="text"
          name="deleteSubcategoriaId"
          placeholder="ID da Subcategoria a Excluir"
          value={deleteSubcategoriaId}
          onChange={(e) => setDeleteSubcategoriaId(e.target.value)}
        />
        <button
          className="bg-pink-500 w-72 text-white p-2 rounded-md hover:bg-pink-600 focus:ring focus:ring-pink-400"
          onClick={handleDeleteSubcategoria}
        >
          Excluir da Subcategoria
        </button>
      </form>
    </div>
  );
}

export default SubcategoriaDelete;
