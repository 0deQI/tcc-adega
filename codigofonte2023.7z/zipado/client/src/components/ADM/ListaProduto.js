import React, { useState, useEffect } from "react";
import Axios from "axios";

function ListaProduto() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    Axios.get("http://localhost:3001/getProdutos").then((response) => {
      setProducts(response.data);
    });
  }, []);

  return (
    <div className="p-4 bg-pink-200 rounded-md">
      <h3 className="text-xl font-semibold ml-5">Lista de Produtos</h3>
      <div className="overflow-x-auto">
        <table className="w-full whitespace-nowrap">
          <thead>
            <tr>
              <th className="p-2 bg-pink-300">ID</th>
              <th className="p-2 bg-pink-300">Nome do Produto</th>
              <th className="p-2 bg-pink-300">Descrição</th>
              <th className="p-2 bg-pink-300">Preço</th>
              <th className="p-2 bg-pink-300">Marca</th>
              <th className="p-2 bg-pink-300">ID da Categoria</th>
              <th className="p-2 bg-pink-300">ID da Subcategoria</th>
              <th className="p-2 bg-pink-300">ID do Fornecedor</th>
              <th className="p-2 bg-pink-300">Imagem</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id_produto}>
                <td className="p-2">{product.id_produto}</td>
                <td className="p-2">{product.nome_produto}</td>
                <td className="p-2">{product.descricao_produto}</td>
                <td className="p-2">{product.valor_produto}</td>
                <td className="p-2">{product.Marca}</td>
                <td className="p-2 text-center">{product.id_categoria_3}</td>
                <td className="p-2 text-center">{product.id_subcategoria_2}</td>
                <td className="p-2 text-center">{product.id_fornecedor_2}</td>
                <td className="p-2 break-all">
                  <a
                    href={product.imagem_produto}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    {product.imagem_produto}
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ListaProduto;
