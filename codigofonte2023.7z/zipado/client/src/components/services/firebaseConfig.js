
import { initializeApp } from "firebase/app";

import { getAuth } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyCcxdMUkgSrHDz-T3GPXv05-p7oL-GLcjc",
  authDomain: "react-auth-bc20e.firebaseapp.com",
  projectId: "react-auth-bc20e",
  storageBucket: "react-auth-bc20e.appspot.com",
  messagingSenderId: "532035584646",
  appId: "1:532035584646:web:eb1ffc39b2728e78934707"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app)