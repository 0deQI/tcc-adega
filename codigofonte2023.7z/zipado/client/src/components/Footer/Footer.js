import React from "react";

function Footer() {
  return (
    <footer className="bottom-0 w-screen/2 bg-black p-4 flex justify-between items-center">
      <div className="flex items-center">
        <i className="fas fa-brands fa-whatsapp text-white hover:opacity-90 w-8 h-8 text-3xl"></i>
        <span className="text-white ml-10 hidden sm:block">000000000000</span>
      </div>
      <div className=""></div>
      <div className="">
        <ul className="list-none m-0 p-0">
          <li className="inline-block mr-5">
            <a href="#">
              <i className="fas fa-brands fa-facebook text-white hover:opacity-90 w-8 h-8 text-3xl"></i>
            </a>
          </li>
          <li className="inline-block">
            <a href="#">
              <i className="fas fa-brands fa-instagram text-white hover:opacity-90 w-8 h-8 text-3xl"></i>
            </a>
          </li>
        </ul>
      </div>
    </footer>
  );
}

export default Footer;
