

export const SliderData = [
  
  {
    image:
      'https://cdn.discordapp.com/attachments/1164348184827547671/1166150839480619049/57d09cc4-abb2-479f-b98c-62861260ef32.png?ex=6549719a&is=6536fc9a&hm=df526dfa46049ecb41c8e6aeca3fbf81883808dc8453a22d2700d97b1556f939&'
  },
  {
    image:
      'https://cdn.discordapp.com/attachments/1164348184827547671/1166150839480619049/57d09cc4-abb2-479f-b98c-62861260ef32.png?ex=6549719a&is=6536fc9a&hm=df526dfa46049ecb41c8e6aeca3fbf81883808dc8453a22d2700d97b1556f939&'
  },
  {
    image:
      'https://cdn.discordapp.com/attachments/1164348184827547671/1166150839480619049/57d09cc4-abb2-479f-b98c-62861260ef32.png?ex=6549719a&is=6536fc9a&hm=df526dfa46049ecb41c8e6aeca3fbf81883808dc8453a22d2700d97b1556f939&'
  },
  {
    image:
      'https://cdn.discordapp.com/attachments/1164348184827547671/1166150839480619049/57d09cc4-abb2-479f-b98c-62861260ef32.png?ex=6549719a&is=6536fc9a&hm=df526dfa46049ecb41c8e6aeca3fbf81883808dc8453a22d2700d97b1556f939&'
  }
];