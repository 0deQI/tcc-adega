import React, { useState, useEffect } from "react";
import Axios from "axios";

const ImageSlider = () => {
  const [slides, setSlides] = useState([]);
  const [current, setCurrent] = useState(0);

  const fetchSliderData = async () => {
    try {
      const response = await Axios.get("http://localhost:3001/getSliderData"); 
      setSlides(response.data);
    } catch (error) {
      console.error("Error fetching slider data:", error);
    }
  };

  useEffect(() => {
    fetchSliderData();
  }, []);

  const length = slides.length;

  const nextSlide = () => {
    setCurrent(current === length - 1 ? 0 : current + 1);
  };

  const prevSlide = () => {
    setCurrent(current === 0 ? length - 1 : current - 1);
  };

  if (!Array.isArray(slides) || slides.length <= 0) {
    return null;
  }

  return (
    <div className="flex justify-center items-center">
      <div style={{ flexGrow: 1 }}>
        <button
          className="border-none cursor-pointer rounded-full text-white bg-black h-9 w-9"
          onClick={prevSlide}
        >
          <i className="fas fa-solid fa-arrow-left"></i>
        </button>
      </div>
      <section>
        {slides.map((slide, index) => {
          return (
            <div className="" key={slide.id_slider}>
              <div className={index === current ? "slide active" : "slide"}>
                {index === current && (
                  <img
                    src={slide.link_slider} // O link_slider contém a URL da imagem
                    alt="slider image"
                    className="w-screen max-h-96"
                  />
                )}
              </div>
            </div>
          );
        })}
      </section>
      <div style={{ flexGrow: 1 }}>
        <button
          className="border-none cursor-pointer rounded-full text-white bg-black h-9 w-9"
          onClick={nextSlide}
        >
          <i className="fas fa-solid fa-arrow-right"></i>
        </button>
      </div>
    </div>
  );
};

export default ImageSlider;
