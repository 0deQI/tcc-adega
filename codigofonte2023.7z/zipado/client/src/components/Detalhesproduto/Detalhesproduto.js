import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { adicionarAoCarrinho } from '../Login/Login';  
import "./Detalhesproduto.css";

function DetalhesDoProduto() {
  const { productId } = useParams();
  const [produtoAtual, setProdutoAtual] = useState(null);
  const [quantidade, setQuantidade] = useState(1);
  const [error, setError] = useState(null);
  const [setIdClienteMessage] = useState('');
  const initialIdCliente = localStorage.getItem('id_cliente');
  const [idCliente, setIdCliente] = useState(initialIdCliente || null);

  
  const diminuirQuantidade = () => {
    if (quantidade > 1) {
      setQuantidade(quantidade - 1);
    }
  };
  
  const aumentarQuantidade = () => {
    setQuantidade(quantidade + 1);
  };

  
  useEffect(() => {
    fetch("http://localhost:3001/getProdutos")
      .then((response) => response.json())
      .then((data) => {
        const produto = data.find((prod) => prod.id_produto === parseInt(productId));
        setProdutoAtual(produto);
      })
      .catch((error) => {
        console.error("Erro ao buscar dados do produto:", error);
      });
  }, [productId]);

  if (!produtoAtual) {
    return <div>Carregando...</div>;
  }

  return (
    <div className="flex items-center justify-center md:h-887 bg-red-200">
      <div className="flex-col md:w-65 w-65 flex justify-center bg-white text-center items-center mt-20 mb-10 p-16 rounded-md" style={{ boxShadow: "0 2px 4px #0000001a" }}>
        <div className="flex bg-white justify-between items-start md:w-65 mb-16 ">
          <div className="image-detalhe md:w-90 object-cover mb-5">
            <img src={produtoAtual.imagem_produto} alt={produtoAtual.nome_produto} className="w-full h-40 object-contain" />
          </div>

          <div className="flex flex-col min-w-340 min-h-600 mt-0">
            <span style={{ whiteSpace: 'nowrap' }} className="text-4xl font-serif font-normal text-center">{produtoAtual.nome_produto}</span>
            <div className="hr"></div>
            <span className="text-lg font-serif font-normal text-left"> R$ {produtoAtual.valor_produto}</span>
            <span className="text-sm font-sans font-normal text-left"> Em até 2x de {produtoAtual.valor_produto / 2} sem juros</span>

            <div className="mt-5 text-left text-sm">
              <span> Quantidade: </span>
              <button className="bg-amber-600 h-6 w-4" onClick={diminuirQuantidade}>-</button>
              <span className="quantidade"> {quantidade} </span>
              <button className="bg-amber-600 h-6 w-4" onClick={aumentarQuantidade}>+</button>
            </div>
            <button
              className="button-price bg-black text-white border-none px-5 py-4 rounded cursor-pointer text-lg font-bold shadow-sm text-center mt-4"
              onClick={() => adicionarAoCarrinho(idCliente, produtoAtual, quantidade, setIdClienteMessage, setError)}
            >
              <span>Adicionar no carrinho</span>
            </button>
            <div className="bg-gray-200 w-400 h-200 mt-24 pt-1 pb-4">
              <div className="frete flex items-center w-10 h-10 mt-2 ml-4">
                <img className="mr-1" src="https://cdn-icons-png.flaticon.com/512/4947/4947662.png" alt="Frete Grátis" />
                <span className="whitespace-nowrap text-base font-normal"> Frete grátis</span>
              </div>
              <span className="frete-texto">
                Frete grátis para pedidos acima de R$ 00.00
              </span>
              <span className="frete-texto">
                Estimado para entrega 00/00/0000 - 00/00/0000!
              </span>

              <div className="devolucao flex items-center w-10 h-10 mt-2 ml-4">
                <img className="mr-1" src="https://pt.seaicons.com/wp-content/uploads/2015/06/shield-ok-icon.png" alt="Devolução Gratuita" />
                <span className="whitespace-nowrap text-base font-normal"> Devolução gratuita</span>
              </div>
              <a href="#" className="devolucao-texto">
                Saiba mais
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DetalhesDoProduto;
