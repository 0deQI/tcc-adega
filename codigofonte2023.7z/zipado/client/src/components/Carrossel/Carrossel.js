import React, { useEffect, useState, useRef } from "react";

import Axios from "axios";

import { Link } from "react-router-dom";

 

function Carrossel() {

  const [listProdutos, setListProdutos] = useState([]);

  const carrossel = useRef(null);

 

  useEffect(() => {

    Axios.get("http://localhost:3001/getProdutos").then((response) => {

      setListProdutos(response.data);

    });

  }, []);

 

  const handleLeftClick = (e) => {

    e.preventDefault();

    if (carrossel.current) {

      carrossel.current.scrollLeft -= carrossel.current.offsetWidth;

    }

  };

 

  const handleRightClick = (e) => {

    e.preventDefault();

    if (carrossel.current) {

      carrossel.current.scrollLeft += carrossel.current.offsetWidth;

    }

  };

 

  return (

    <div className="w-full min-h-10vh text-gray-900 flex justify-center items-center mt-5 ">

      <div className="" style={{ maxWidth: "80vw",}}>

        <div className="flex justify-center align-center">

          <h2 className="p-4 text-2xl font-semibold">Todos Produtos!</h2>

        </div>

        <div className="flex" >

        <button

              className="border-none flex-none self-center  cursor-pointer rounded-full text-black bg-[#f4dbc9]  h-9 w-9 mt-1/2"

              onClick={handleLeftClick}

            >

  <i className="fas fa-solid fa-arrow-left "></i>

            </button> <div

          ref={carrossel}

          className="flex overflow-y-hidden overflow-x-hidden bg-white rounded-md h-410px"

          style={{ scrollBehavior: "smooth" }}

        >

          <div className="w-full text-center flex items-center justify-center">

           

         

          </div>

          {listProdutos.map((item) => {

            const { id_produto, nome_produto, valor_produto, imagem_produto } = item;

            return (

              <Link to={`/products/${id_produto}`} key={id_produto}>

                <div

                  className="bg-[#ffffff] m-5 p-3 rounded-[16px] flex-none items-center cursor-pointer"

                  style={{ width: "220px" }}

                >

                  <div className="w-200px h-190px object-cover flex justify-center items-center">

                    <img

                      className="w-full h-40 object-contain"

                      src={imagem_produto}

                      alt={nome_produto}

                    />

                  </div>

                  <div

                    className="flex flex-col justify-between"

                    style={{ height: "110px" }}

                  >

                    <span

                      className="block text-center text-[#1e1e1e] p-1 rounded-[10px]

                       text-lg font-normal my-1"

                      style={{

                        backgroundColor: "white",

                      }}

                    >

                      {nome_produto}

                    </span>

                    <button className="mt-0 text-lg font-semibold

                    bg-[#ffffff] rounded-[10px] cursor-pointer min-h-[40px]">

                      <span>R$ {valor_produto}</span>

                    </button>

                  </div>

                </div>

              </Link>

            );

          })}

         

        </div>

        <button

               className=" right-[-18px] border-none self-center cursor-pointer rounded-full text-black bg-[#f4dbc9]  h-9 w-9 flex-none"

              onClick={handleRightClick}

            >

          <i className="fas fa-solid fa-arrow-right "></i>

            </button>

      </div>

      </div>

    </div>

  );

}

 

export default Carrossel;