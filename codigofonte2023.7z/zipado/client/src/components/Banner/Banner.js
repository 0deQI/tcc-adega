import React, { useEffect, useState } from "react";
import Axios from "axios";

function Banner() {
  const [banner, setBanner] = useState(null);

  useEffect(() => {
    Axios.get("http://localhost:3001/getBanners")
      .then((response) => {
        if (response.data.length > 0) {
          setBanner(response.data[0]); // pega o primeiro banner
        }
      })
      .catch((error) => {
        console.error("Erro ao buscar banners:", error);
      });
  }, []);

  return (
    <div className="w-screen/2 bg-pink-200 max-h-96">
      {banner && (
        <div>
          
            <img
              src={banner.link_banner}
              alt={`Banner ${banner.id_banner}`}
              className=" w-screen max-h-96"
            />
      
        </div>
      )}
    </div>
  );
}

export default Banner;