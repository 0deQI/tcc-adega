import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSignInWithEmailAndPassword } from 'react-firebase-hooks/auth';
import { auth } from '../services/firebaseConfig';
import { signOut } from 'firebase/auth';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom'; 
import { Link } from 'react-router-dom';

import ADMPage from '../../pages/ADM/ADMPage';
const diminuirQuantidade = (quantidade, setQuantidade) => {
  if (quantidade > 1) {
    setQuantidade(quantidade - 1);
  }
};


const aumentarQuantidade = (quantidade, setQuantidade) => {
  setQuantidade(quantidade + 1);
};


const adicionarAoCarrinho = async (idCliente, produtoAtual, quantidade, setIdClienteMessage, setError) => {
  if (idCliente) {
    if (quantidade > 0) {
      const produtoParaAdicionar = {
        id_produto: produtoAtual.id_produto,
        quantidade,
        id_cliente: idCliente,
      };

      try {
        const response = await fetch("http://localhost:3001/adicionarAoCarrinho", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(produtoParaAdicionar),
        });

        if (response.ok) {
          const message = 'id_cliente encontrado';
          console.log("Produto adicionado ao carrinho com sucesso.");
          setIdClienteMessage(message);

          // Show a success alert
          window.alert('Produto adicionado ao carrinho com sucesso');
        } else {
          console.error("Erro ao adicionar ao carrinho:", response.statusText);
          setError("Erro ao adicionar ao carrinho.");
        }
      } catch (error) {
        console.error("Erro ao adicionar ao carrinho:", error);
        setError("Erro ao adicionar ao carrinho.");
      }
    } else {
      setError("A quantidade deve ser maior que zero.");
    }
  } else {
    window.alert('Não é possível adicionar ao carrinho. Entre em uma conta primeiro.');
  }
};
function Login({ openCadastroModal, closeModal, onLogin }) {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const initialIdCliente = localStorage.getItem('id_cliente');
  const [idCliente, setIdCliente] = useState(initialIdCliente || null);
  const [error, setError] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [signInWithEmailAndPasswordFirebase, , loading] = useSignInWithEmailAndPassword(auth);
  const handleSignIn = async (e) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, email, password);
      const user = auth.currentUser;

      if (user) {
        const token = await user.getIdToken();

        axios
          .get('http://localhost:3001/api/getUserId', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          })
          .then((response) => {
            const idCliente = response.data.id_cliente;
            console.log('idCliente:', idCliente);
            localStorage.setItem('id_cliente', idCliente);
            setIdCliente(idCliente);
            closeModal();
            onLogin(idCliente);
          })
          .catch((error) => {
            console.error('Erro ao obter o ID do cliente:', error);
          });
      }
    } catch (error) {
      setError('Email ou seha incorretos');
    }
  };

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        setUser(user);
        setIsLoggedIn(true);

        try {
          signInWithEmailAndPasswordFirebase(email, password)
            .then((userCredential) => {
              userCredential.user.getIdToken()
                .then((token) => {
                  axios.get('http://localhost:3001/api/getUserId', {
                    headers: {
                      Authorization: `Bearer ${token}`,
                    },
                  })
                    .then((response) => {
                      setIdCliente(response.data.id_cliente);
                      closeModal();
                    })
                    .catch((error) => {
                      console.error('Erro ao obter o ID do cliente:', error);
                    });
                })
                .catch((error) => {
                  console.error('Erro ao obter o token JWT:', error);
                });
            })
            .catch((error) => {
              setError('Email ou senha incorretos');
            });
        } catch (error) {
          console.error('Erro ao buscar o ID do cliente:', error);
        }
      } else {
        setUser(null);
        setIsLoggedIn(false);
        setIdCliente(null);
      }
    });

    return () => unsubscribe();
  }, [email, password]);

  const handleSignOut = async () => {
    await signOut(auth);
    setIsLoggedIn(false);
    setUser(null);
    setIdCliente(null);
    localStorage.removeItem('id_cliente');
  };

  return (
    <div>
      {isLoggedIn ? (
        <div>
          <p className='text-black'>{`Você está logado como ${user?.email} (ID do Cliente: ${idCliente})`}</p>
          {user?.email === 'felica@gmail.com' && (
       <button
       className="bg-pink-400 hover:bg-pink-600 text-white py-2 px-4 rounded mt-4"
     >
       <Link to="/ADMpage2232324423">ADM</Link>
     </button>
          )}
          <button
            className="bg-black hover:bg-gray-800 text-white py-2 px-4 rounded mt-4"
            onClick={handleSignOut}
          >
            Sair
          </button>
        </div>
      ) : (
        <form className="text-2xl font-semibold mb-4 text-black">
          <div className="mb-4">
            <label className="block text-gray-700 font-bold mb-2" htmlFor="email">
              Email
            </label>
            <input
              className="border rounded w-full py-2 px-3"
              type="email"
              id="email"
              placeholder="Digite seu email"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="mb-4">
            <label
              className="block text-gray-700 font-bold mb-2"
              htmlFor="senha"
            >
              Senha
            </label>
            <input
              className="border rounded w-full py-2 px-3"
              type="password"
              id="senha"
              placeholder="Digite sua senha"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <div className="mb-4">
            <button
              className="bg-blue-500 hover:bg-blue-700 text-white py-2 px-4 rounded"
              onClick={openCadastroModal}
              type="button"
            >
              Cadastre-se
            </button>
          </div>
          <button
            className="bg-black hover:bg-gray-800 text-white py-2 px-4 rounded mt-4"
            onClick={handleSignIn}
          >
            Entrar
          </button>

          {error && <p className="text-red-500 mt-2">{error}</p>}
        </form>
      )}
    </div>
  );
}

export default Login;
export { diminuirQuantidade, aumentarQuantidade, adicionarAoCarrinho };