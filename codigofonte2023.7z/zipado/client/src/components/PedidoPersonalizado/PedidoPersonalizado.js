import React from 'react';

function PedidoPersonalizado() {
  return (
    <div className="w-screen/2 h-96 bg-slate-100 flex flex-row">
      <div className="h-96 bg-slate-50 w-full"></div>
      <div className="h-96 opacity-100 bg-gradient-to-r from-transparent to-red-200 w-1/5"></div>
      <div className="h-96 bg-red-200 w-full">
        <div className="flex flex-col ml-5 p-5 justify-center h-full  ">
          <div className="text-lg font-serif font-normal">Peça drinks diretamente pelo nosso whats!</div>
          <div className='text-2lg font-serif font-normal mt-1'>Peça seu pedido personalizado!</div>
         
        </div>
      </div>
    </div>
  );
}

export default PedidoPersonalizado;